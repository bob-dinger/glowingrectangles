# d3_bubble_force

A Pen created on CodePen.

Original URL: [https://codepen.io/glowinggardens/pen/xxLYEvj](https://codepen.io/glowinggardens/pen/xxLYEvj).

