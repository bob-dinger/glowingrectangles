<template>
  <div></div>
</template>

<script setup>
//image of visuals related to buildings in bliss symbolices
</script>

<style scoped></style>
