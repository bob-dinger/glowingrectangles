<template>
  <div
    id="card"
    class="mt-24"
    style="margin-top: 100px; padding-left: 20%; padding-right: 20%"
  >
    <div class="mb-8">We tell ourselves:</div>
    <div>
      <ul>
        <li>"I'm going to the gym tomorrow morning at 5am"</li>
        <li>"I'm not going to be attracted to that type of person anymore"</li>
        <li>"I'm not going to eat dessert tonight"</li>
        <li>"I'm not going to look at twitter or Instagram today"</li>
        <li>"I'm only going to have 2 drinks tonight"</li>
      </ul>
    </div>
  </div>
</template>

<script setup></script>

<style scoped></style>
