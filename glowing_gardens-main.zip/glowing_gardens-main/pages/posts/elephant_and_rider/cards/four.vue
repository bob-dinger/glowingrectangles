<template>
  <div
    id="card"
    class="mt-8"
    style="margin-top: 100px; padding-left: 30%; padding-right: 30%"
  >
    <div>And then BOOM</div>
    <div>
      The alarm goes off at 5am, and we find a way to justify not getting out of bed. It's
      too early. I'll start tomorrow.
    </div>
  </div>
</template>

<script setup></script>

<style scoped></style>
