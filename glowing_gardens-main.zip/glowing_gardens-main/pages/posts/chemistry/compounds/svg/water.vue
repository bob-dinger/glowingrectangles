<template>
  <div></div>
</template>

<script setup>
//use d3 to show a water molecule
</script>

<style scoped></style>
