<template>
  <div>a protein is nothing more than a long chain of amino acids.</div>
  <div>those with fewer than 50 amino acids in the chain are called peptides.</div>
  <div>those with more are called proteins</div>
</template>

<script setup>
//20 amino acids in the human body

let acids = ref([
  {
    name: "leucine",
    url: "https://en.wikipedia.org/wiki/Leucine",
  },
]);
</script>

<style scoped></style>
