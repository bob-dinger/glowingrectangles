baseletters
double helix
chromosomes
within each cell








in each of our cells we have a full copy of all our DNA

it is 3 billion base pairs long

it is within chromosomes in the nucleus of each of our cells. 

our bodies read these instructions and create amino acids

these amino acids make up protiens that are created within the cell that has the DNA data in the nucleus. 





