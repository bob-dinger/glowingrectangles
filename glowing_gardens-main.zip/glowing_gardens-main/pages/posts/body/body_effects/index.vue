<template>
  <div></div>
</template>

<script setup>
//meal (glh-1, insulin, metabolism)
//alcohol
//sugar
//adderall
//caffeine
//nicotine
//weed
//mushrooms
//lsd

let effects = ref([
  {
    name: "drinking alcohol",
  },
  {
    name: "eating food",
  },
  {
    name: "eating sugar",
  },
  {
    name: "drinking caffeine",
  },
  {
    name: "taking adderall",
  },
  {
    name: "smoking weed",
  },
  {
    name: "smoking a cigarette",
  },
]);
</script>

<style scoped></style>
