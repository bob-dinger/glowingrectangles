<template>
  <div></div>
</template>

<script setup>
//saliva production
//chewing
//stomach acid
//pepsin (enzyme)
//small intestine releases hormons like (secretin, cholecystokinin, and gastric inhibitory peptide)
</script>

<style scoped></style>
