<template>
  <div id="container">
    <svg
      id="Layer_1"
      data-name="Layer 1"
      viewBox="0 0 799.99996 800"
      version="1.1"
      sodipodi:docname="nervous_system.svg"
      width="800"
      height="800"
      inkscape:version="1.1.2 (b8e25be833, 2022-02-05)"
      xmlns:inkscape="http://www.inkscape.org/namespaces/inkscape"
      xmlns:sodipodi="http://sodipodi.sourceforge.net/DTD/sodipodi-0.dtd"
      xmlns:xlink="http://www.w3.org/1999/xlink"
      xmlns="http://www.w3.org/2000/svg"
      xmlns:svg="http://www.w3.org/2000/svg"
    >
      <defs id="defs182">
        <linearGradient
          id="linear-gradient"
          x1="102.24"
          y1="684.75"
          x2="216.08"
          y2="684.75"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0" stop-color="#f3d244" id="stop4" />
          <stop offset=".02" stop-color="#f3d345" id="stop6" />
          <stop offset=".23" stop-color="#f3dd4d" id="stop8" />
          <stop offset=".5" stop-color="#f4e050" id="stop10" />
          <stop offset=".84" stop-color="#f4dd4e" id="stop12" />
          <stop offset=".98" stop-color="#f4d648" id="stop14" />
          <stop offset="1" stop-color="#f4d547" id="stop16" />
        </linearGradient>
        <linearGradient
          id="linear-gradient-2"
          x1="102.24"
          y1="694.62"
          x2="216.08"
          y2="694.62"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-3"
          x1="102.24"
          y1="697.65002"
          x2="216.09"
          y2="697.65002"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-4"
          x1="102.24"
          y1="696.96997"
          x2="216.08"
          y2="696.96997"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-5"
          x1="102.24"
          y1="701.39001"
          x2="216.08"
          y2="701.39001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-6"
          x1="102.24"
          y1="587.59998"
          x2="216.08"
          y2="587.59998"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-7"
          x1="102.24"
          y1="534.37"
          x2="216.08"
          y2="534.37"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-8"
          x1="102.24"
          y1="564.01001"
          x2="216.08"
          y2="564.01001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-9"
          x1="102.24"
          y1="534.83002"
          x2="216.09"
          y2="534.83002"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-10"
          x1="102.24"
          y1="593.88"
          x2="216.09"
          y2="593.88"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-11"
          x1="102.24"
          y1="550.27002"
          x2="216.08"
          y2="550.27002"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-12"
          x1="102.24"
          y1="594"
          x2="216.08"
          y2="594"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-13"
          x1="102.24"
          y1="637.40997"
          x2="216.09"
          y2="637.40997"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-14"
          x1="102.24"
          y1="508.10001"
          x2="216.08"
          y2="508.10001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-15"
          x1="102.24"
          y1="476.73001"
          x2="216.08"
          y2="476.73001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-16"
          x1="102.24"
          y1="456.32001"
          x2="216.08"
          y2="456.32001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-17"
          x1="93.309998"
          y1="414.98999"
          x2="96.080002"
          y2="414.98999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-18"
          x1="102.24"
          y1="392.23001"
          x2="216.08"
          y2="392.23001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-19"
          x1="102.24"
          y1="383.10999"
          x2="216.08"
          y2="383.10999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-20"
          x1="102.24"
          y1="404.79999"
          x2="216.08"
          y2="404.79999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-21"
          x1="102.24"
          y1="413.89999"
          x2="216.08"
          y2="413.89999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-22"
          x1="102.24"
          y1="523.81"
          x2="216.09"
          y2="523.81"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-23"
          x1="102.24"
          y1="554.04999"
          x2="216.09"
          y2="554.04999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-24"
          x1="102.24"
          y1="389.01001"
          x2="216.08"
          y2="389.01001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-25"
          x1="102.24"
          y1="321.60999"
          x2="216.08"
          y2="321.60999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-26"
          x1="102.24"
          y1="250.10001"
          x2="216.08"
          y2="250.10001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-27"
          x1="102.24"
          y1="233.46001"
          x2="216.08"
          y2="233.46001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-28"
          x1="102.24"
          y1="267.56"
          x2="216.08"
          y2="267.56"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-29"
          x1="102.24"
          y1="267.42001"
          x2="216.08"
          y2="267.42001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-30"
          x1="18.32"
          y1="270.47"
          x2="132.16"
          y2="270.47"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-31"
          x1="102.24"
          y1="337.64999"
          x2="216.08"
          y2="337.64999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-32"
          x1="102.24"
          y1="351.92001"
          x2="216.08"
          y2="351.92001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-33"
          x1="102.24"
          y1="352.70999"
          x2="216.09"
          y2="352.70999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-34"
          x1="102.24"
          y1="332.07999"
          x2="216.08"
          y2="332.07999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-35"
          x1="102.24"
          y1="332.04999"
          x2="216.08"
          y2="332.04999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-36"
          x1="102.24"
          y1="306.16"
          x2="216.08"
          y2="306.16"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-37"
          x1="102.24"
          y1="222.25999"
          x2="216.08"
          y2="222.25999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-38"
          x1="102.24"
          y1="216.08"
          x2="216.08"
          y2="216.08"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-39"
          x1="102.24"
          y1="207.81"
          x2="216.08"
          y2="207.81"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-40"
          x1="102.24"
          y1="195.88"
          x2="216.08"
          y2="195.88"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-41"
          x1="102.24"
          y1="184.07001"
          x2="216.08"
          y2="184.07001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-42"
          x1="102.24"
          y1="175.78"
          x2="216.08"
          y2="175.78"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-43"
          x1="102.24"
          y1="165.61"
          x2="216.08"
          y2="165.61"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-44"
          x1="102.24"
          y1="155.59"
          x2="216.08"
          y2="155.59"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-45"
          x1="102.24"
          y1="145.07001"
          x2="216.08"
          y2="145.07001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-46"
          x1="102.24"
          y1="134.75999"
          x2="216.08"
          y2="134.75999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-47"
          x1="102.24"
          y1="77.669998"
          x2="216.08"
          y2="77.669998"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-48"
          x1="102.24"
          y1="143.38"
          x2="216.09"
          y2="143.38"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-49"
          x1="102.24"
          y1="107.47"
          x2="216.08"
          y2="107.47"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-50"
          x1="102.24"
          y1="115.13"
          x2="216.08"
          y2="115.13"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-51"
          x1="102.24"
          y1="166.82001"
          x2="216.08"
          y2="166.82001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-52"
          x1="102.24"
          y1="174.75"
          x2="216.08"
          y2="174.75"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-53"
          x1="102.24"
          y1="178.13"
          x2="216.08"
          y2="178.13"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-54"
          x1="102.24"
          y1="255.77"
          x2="216.08"
          y2="255.77"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-55"
          x1="7.2800002"
          y1="347.82999"
          x2="44.240002"
          y2="347.82999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-56"
          x1="16.15"
          y1="363.54999"
          x2="42.66"
          y2="363.54999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-57"
          x1="25.959999"
          y1="372.67999"
          x2="38.639999"
          y2="372.67999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-58"
          x1="33.709999"
          y1="367.79999"
          x2="39.349998"
          y2="367.79999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-59"
          x1="44.240002"
          y1="366.04999"
          x2="47.349998"
          y2="366.04999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-60"
          x1="102.24"
          y1="308.39999"
          x2="216.08"
          y2="308.39999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-61"
          x1="102.24"
          y1="684.45001"
          x2="216.09"
          y2="684.45001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-62"
          x1="102.24"
          y1="662.31"
          x2="216.09"
          y2="662.31"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-63"
          x1="102.24"
          y1="681.07001"
          x2="216.08"
          y2="681.07001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-64"
          x1="102.24"
          y1="674.70001"
          x2="216.08"
          y2="674.70001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-65"
          x1="102.24"
          y1="516.60999"
          x2="216.08"
          y2="516.60999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-66"
          x1="102.24"
          x2="216.08"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-67"
          x1="102.24"
          y1="694.62"
          x2="216.08"
          y2="694.62"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-68"
          x1="102.24"
          y1="697.65002"
          x2="216.08"
          y2="697.65002"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-69"
          x1="102.24"
          y1="696.96997"
          x2="216.08"
          y2="696.96997"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-70"
          x1="102.24"
          y1="701.39001"
          x2="216.08"
          y2="701.39001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-71"
          x1="102.24"
          y1="587.59998"
          x2="216.08"
          y2="587.59998"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-72"
          x1="102.23"
          y1="534.37"
          x2="216.08"
          y2="534.37"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-73"
          x1="102.24"
          y1="564.01001"
          x2="216.08"
          y2="564.01001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-74"
          x1="102.23"
          y1="534.83002"
          x2="216.08"
          y2="534.83002"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-75"
          x1="102.24"
          y1="593.88"
          x2="216.08"
          y2="593.88"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-76"
          x1="102.24"
          y1="550.27002"
          x2="216.08"
          y2="550.27002"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-77"
          x1="102.24"
          y1="594"
          x2="216.08"
          y2="594"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-78"
          x1="102.24"
          y1="637.40997"
          x2="216.08"
          y2="637.40997"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-79"
          x1="102.24"
          y1="508.10001"
          x2="216.08"
          y2="508.10001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-80"
          x1="102.24"
          y1="476.73001"
          x2="216.08"
          y2="476.73001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-81"
          x1="102.24"
          y1="456.32001"
          x2="216.09"
          y2="456.32001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-82"
          x1="102.24"
          y1="414.98999"
          x2="216.08"
          y2="414.98999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-83"
          x1="102.24"
          y1="392.23001"
          x2="216.08"
          y2="392.23001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-84"
          x1="102.24"
          y1="383.10999"
          x2="216.08"
          y2="383.10999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-85"
          x1="102.24"
          y1="404.79999"
          x2="216.08"
          y2="404.79999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-86"
          x1="102.24"
          y1="413.89999"
          x2="216.08"
          y2="413.89999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-87"
          x1="102.24"
          y1="523.81"
          x2="216.08"
          y2="523.81"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-88"
          x1="102.24"
          y1="553.46997"
          x2="216.08"
          y2="553.46997"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-89"
          x1="102.24"
          y1="389.01001"
          x2="216.08"
          y2="389.01001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-90"
          x1="102.24"
          y1="321.60999"
          x2="216.08"
          y2="321.60999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-91"
          x1="102.24"
          y1="250.10001"
          x2="216.08"
          y2="250.10001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-92"
          x1="102.24"
          y1="233.46001"
          x2="216.08"
          y2="233.46001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-93"
          x1="102.24"
          y1="267.56"
          x2="216.08"
          y2="267.56"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-94"
          x1="102.24"
          y1="267.42001"
          x2="216.08"
          y2="267.42001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-95"
          x1="186.16"
          y1="270.82999"
          x2="300.01001"
          y2="270.82999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-96"
          x1="102.24"
          y1="337.64999"
          x2="216.08"
          y2="337.64999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-97"
          x1="102.24"
          y1="351.92001"
          x2="216.08"
          y2="351.92001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-98"
          x1="102.24"
          y1="352.70999"
          x2="216.08"
          y2="352.70999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-99"
          x1="102.24"
          y1="332.07999"
          x2="216.08"
          y2="332.07999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-100"
          x1="102.24"
          y1="332.04999"
          x2="216.08"
          y2="332.04999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-101"
          x1="102.24"
          y1="306.16"
          x2="216.08"
          y2="306.16"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-102"
          x1="102.24"
          y1="222.25999"
          x2="216.08"
          y2="222.25999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-103"
          x1="102.24"
          y1="216.08"
          x2="216.08"
          y2="216.08"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-104"
          x1="102.24"
          y1="207.81"
          x2="216.08"
          y2="207.81"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-105"
          x1="102.24"
          y1="195.88"
          x2="216.08"
          y2="195.88"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-106"
          x1="102.24"
          y1="184.07001"
          x2="216.08"
          y2="184.07001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-107"
          x1="102.24"
          y1="175.78"
          x2="216.08"
          y2="175.78"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-108"
          x1="102.24"
          y1="165.61"
          x2="216.08"
          y2="165.61"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-109"
          x1="102.24"
          y1="155.59"
          x2="216.08"
          y2="155.59"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-110"
          x1="102.24"
          y1="145.07001"
          x2="216.08"
          y2="145.07001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-111"
          x1="102.24"
          y1="134.75999"
          x2="216.08"
          y2="134.75999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-112"
          x1="102.24"
          y1="77.669998"
          x2="216.08"
          y2="77.669998"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-113"
          x1="102.24"
          y1="143.38"
          x2="216.09"
          y2="143.38"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-114"
          x1="102.24"
          y1="107.47"
          x2="216.08"
          y2="107.47"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-115"
          x1="102.24"
          y1="115.13"
          x2="216.08"
          y2="115.13"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-116"
          x1="102.24"
          y1="166.82001"
          x2="216.08"
          y2="166.82001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-117"
          x1="102.24"
          y1="174.75"
          x2="216.08"
          y2="174.75"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-118"
          x1="102.24"
          y1="178.13"
          x2="216.08"
          y2="178.13"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-119"
          x1="102.24"
          y1="255.77"
          x2="216.08"
          y2="255.77"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-120"
          x1="102.24"
          y1="347.82999"
          x2="216.08"
          y2="347.82999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-121"
          x1="102.24"
          y1="363.54999"
          x2="216.08"
          y2="363.54999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-122"
          x1="102.24"
          y1="372.67999"
          x2="216.09"
          y2="372.67999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-123"
          x1="102.24"
          y1="367.79999"
          x2="216.08"
          y2="367.79999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-124"
          x1="102.23"
          y1="366.04999"
          x2="216.08"
          y2="366.04999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-125"
          x1="40.189999"
          y1="293.12"
          x2="80.050003"
          y2="293.12"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-126"
          x1="879.03003"
          y1="293.12"
          x2="919.15997"
          y2="293.12"
          gradientTransform="matrix(-1,0,0,1,1400.8698,28.077886)"
          xlink:href="#linear-gradient"
        />
        <linearGradient
          id="linear-gradient-127"
          x1="102.24"
          y1="308.39999"
          x2="216.08"
          y2="308.39999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-128"
          x1="102.24"
          y1="684.45001"
          x2="216.08"
          y2="684.45001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-129"
          x1="102.23"
          y1="662.31"
          x2="216.08"
          y2="662.31"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-130"
          x1="102.24"
          y1="681.07001"
          x2="216.08"
          y2="681.07001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-131"
          x1="102.24"
          y1="674.70001"
          x2="216.09"
          y2="674.70001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-132"
          x1="102.24"
          y1="516.60999"
          x2="216.08"
          y2="516.60999"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-133"
          x1="33.860001"
          y1="290.67001"
          x2="67"
          y2="290.67001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-134"
          x1="102.24"
          y1="221.85001"
          x2="216.08"
          y2="221.85001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-135"
          x1="102.24"
          y1="290.67001"
          x2="216.08"
          y2="290.67001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <linearGradient
          id="linear-gradient-136"
          x1="102.24"
          y1="221.85001"
          x2="216.08"
          y2="221.85001"
          xlink:href="#linear-gradient"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <radialGradient
          id="radial-gradient"
          cx="141.91"
          cy="25.1"
          fx="141.91"
          fy="25.1"
          r="17.059999"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset=".2" stop-color="#e1795c" id="stop154" />
          <stop offset=".53" stop-color="#e0755b" id="stop156" />
          <stop offset=".78" stop-color="#de6c58" id="stop158" />
          <stop offset="1" stop-color="#dc5d54" id="stop160" />
        </radialGradient>
        <radialGradient
          id="radial-gradient-2"
          cx="140.21001"
          cy="44.810001"
          fx="140.21001"
          fy="44.810001"
          r="11.06"
          xlink:href="#radial-gradient"
        />
        <radialGradient
          id="radial-gradient-3"
          cx="144.67"
          cy="55.720001"
          fx="144.67"
          fy="55.720001"
          r="10.48"
          xlink:href="#radial-gradient"
        />
        <radialGradient
          id="radial-gradient-4"
          cx="171.48"
          fx="171.48"
          r="17.059999"
          xlink:href="#radial-gradient"
        />
        <radialGradient
          id="radial-gradient-5"
          cx="173.17999"
          cy="44.810001"
          fx="173.17999"
          fy="44.810001"
          r="11.06"
          xlink:href="#radial-gradient"
        />
        <radialGradient
          id="radial-gradient-6"
          cx="168.73"
          cy="55.720001"
          fx="168.73"
          fy="55.720001"
          r="10.48"
          xlink:href="#radial-gradient"
        />
        <linearGradient
          id="linear-gradient-137"
          x1="152.2"
          y1="191.59"
          x2="161.95"
          y2="191.59"
          gradientUnits="userSpaceOnUse"
        >
          <stop offset="0" stop-color="#f3d244" id="stop168" />
          <stop offset=".12" stop-color="#f4e057" id="stop170" />
          <stop offset=".33" stop-color="#f6f472" id="stop172" />
          <stop offset=".45" stop-color="#f7fc7d" id="stop174" />
          <stop offset=".53" stop-color="#f6f574" id="stop176" />
          <stop offset="1" stop-color="#f4d547" id="stop178" />
        </linearGradient>
        <radialGradient
          id="radial-gradient-7"
          cx="156.7"
          cy="46.389999"
          fx="156.7"
          fy="46.389999"
          r="7.4699998"
          xlink:href="#radial-gradient"
        />
        <linearGradient
          inkscape:collect="always"
          xlink:href="#linear-gradient"
          id="linearGradient1352"
          gradientUnits="userSpaceOnUse"
          x1="102.24"
          y1="684.75"
          x2="216.08"
          y2="684.75"
          gradientTransform="translate(248.68985,28.077886)"
        />
        <radialGradient
          inkscape:collect="always"
          xlink:href="#radial-gradient"
          id="radialGradient1354"
          gradientUnits="userSpaceOnUse"
          cx="141.91"
          cy="25.1"
          fx="141.91"
          fy="25.1"
          r="17.059999"
        />
      </defs>
      <path
        class="cls-133"
        d="m 560.36985,389.10789 c -3.19,-2.23 -7.07,-4.62 -13.88,-12.89 -4.07,-4.94 -9.72,-8.4 -15.66,-10.69 -1.09,-0.42 -2.21,-0.8 -3.16,-1.48 -1.95,-1.39 -2.28,-4.28 -2.81,-6.46 -0.53,-2.16 -0.94,-4.35 -1.52,-6.49 -1.17,-4.33 -2.23,-11.2 -2.23,-22.7 0,-27.25 -5.6,-50.76 -8.58,-57.11 -2.99,-6.35 -4.85,-11.2 -8.34,-36.95 -3.48,-25.75 3.23,-21.52 0,-52.63 -3.23,-31.1 -27.12,-36.58 -37.82,-39.07 -10.7,-2.49 -32.6,-11.51 -36.83,-14.74 -2.09,-1.6 -2.42,-9.71 -2.22,-17.53 3.27,-5.02 4.96,-11.640004 6.15,-17.430004 0.51,0.65 1.59,1.87 2.56,1.94 1.33,0.1 3.28,-4.1 3.89,-6.35 0.61,-2.25 1.43,-9.93 0.51,-12.8 -0.92,-2.87 -3.07,-0.61 -3.79,0.51 -0.26,0.41 -0.8,0.79 -1.37,1.12 0.2,-3.79 0.39,-7.58 0.94,-11.35 1.08,-7.42 0.59,-14.56 -1.93,-21.72 -5.3,-15.08 -26.02,-16.14 -28.89,-16.21 v 0 c 0,0 0,0 0,0 v 0 c 0,0 -0.01,0 -0.01,0 -2.88,0.07 -23.59,1.13 -28.9,16.23 -2.51,7.15 -3.01,14.29 -1.93,21.72 0.55,3.76 0.74,7.55 0.94,11.35 -0.57,-0.32 -1.11,-0.71 -1.37,-1.12 -0.72,-1.13 -2.87,-3.38 -3.79,-0.51 -0.92,2.87 -0.1,10.55 0.51,12.8 0.61,2.25 2.56,6.45 3.89,6.35 0.97,-0.07 2.04,-1.29 2.56,-1.94 1.19,5.79 2.88,12.410004 6.15,17.430004 0.2,7.82 -0.13,15.93 -2.22,17.53 -4.23,3.23 -26.13,12.26 -36.83,14.74 -10.7,2.49 -34.59,7.96 -37.82,39.07 -3.23,31.1 3.48,26.87 0,52.63 -3.48,25.75 -5.35,30.61 -8.34,36.95 -2.99,6.35 -8.58,29.86 -8.58,57.11 0,11.49 -1.06,18.37 -2.23,22.7 -0.58,2.14 -0.99,4.33 -1.52,6.49 -0.53,2.18 -0.86,5.07 -2.81,6.46 -0.95,0.68 -2.07,1.06 -3.16,1.48 -5.95,2.29 -11.59,5.75 -15.66,10.69 -6.81,8.26 -10.68,10.65 -13.88,12.89 -3.19,2.23 -2.15,7.9 5.15,6.24 7.29,-1.66 12.12,-10.91 13.91,-10.36 1.8,0.55 -1.99,14.25 -3.5,18.87 -1.51,4.62 -2.96,10.18 -3.93,13 -0.96,2.83 -2.02,8.04 0.12,10.93 2.14,2.89 5.18,-0.84 7.29,-8.27 2.11,-7.43 6.44,-20.7 6.44,-20.7 0,0 -2.39,11.2 -4.15,17.98 -1.76,6.78 -6.31,15.46 -2.43,18.72 2.05,1.72 4.47,-0.47 5.83,-3.74 1.37,-3.31 3.07,-8.83 3.19,-9.37 1.28,-5.54 5.07,-20.76 5.07,-20.76 0,0 -2.45,12.76 -3.88,18.82 -0.8,3.38 -2.69,7.79 -2.68,10.51 0,2.15 1.68,3.61 3.93,2.94 2.01,-0.6 3.79,-5.12 4.97,-9.9 1.21,-4.9 3.02,-13.82 4.11,-18.02 0.41,-1.59 1.11,-3.17 1.07,-1.97 -0.1,2.59 -2.11,9.66 -2.76,13.2 -0.83,4.48 -0.68,7.65 1.44,7.91 1.33,0.16 2.49,-0.17 3.63,-2.14 1.31,-2.26 2.6,-8.2 3.53,-12.39 1.51,-6.8 3.6,-13.05 4.47,-19.16 0.88,-6.11 2.14,-18.59 3.08,-22.68 0.94,-4.09 2.87,-9.43 2.87,-9.43 l -0.13,-0.02 c 3.71,-11.5 12.66,-39.11 18.45,-55.93 7.47,-21.65 4.85,-29.11 5.97,-38.44 0.73,-6.05 7.11,-21.22 11.7,-37.45 6.96,14.58 14.12,36.05 9.83,57.23 -7.54,37.21 -5.18,26.37 -7.54,37.21 -2.6,11.94 -5.22,23.66 -6.4,35.88 -2.64,27.29 -4.69,54.92 -0.35,81.93 1.58,9.85 7.31,66.9 6.95,68.88 -1.35,7.43 -5.74,22.98 -7.43,31.76 -1.69,8.78 -0.83,21.96 -0.15,45.95 0.68,23.99 3.72,42.57 4.73,55.75 0.87,11.31 -0.79,40.23 -1.28,48.19 -0.09,1.4 -0.34,2.76 -0.79,4.09 -0.98,2.92 -2.51,7.02 -4.35,10.57 -3.29,6.32 -10.87,18.21 -13.4,20.74 -2.53,2.53 -6.61,8.63 -2.78,10.37 1.34,0.61 2.02,0.03 2.02,0.03 -0.51,1.99 0.37,4.09 1.58,4.68 0.98,0.47 2.21,0.35 2.21,0.35 0.11,1.55 1.9,4.46 5.69,3.41 0,0 0.96,3.39 3.9,3.54 0.97,0.05 1.93,0.01 2.84,-0.35 0.83,-0.33 1.75,-1.28 2.74,-3.64 0,0 -0.75,3.04 2.98,4.49 3.73,1.45 8.16,-0.25 10.43,-5.06 2.28,-4.81 2.02,-5.69 3.92,-9.86 1.9,-4.17 1.01,-15.05 2.4,-19.47 1.39,-4.43 5.44,-5.94 5.82,-9.61 0.23,-2.2 0.31,-6.4 -0.2,-10.37 0.09,-0.02 0.26,-16.54 0.26,-16.54 l 0.48,-7.37 c 0.74,-11.39 2.14,-22.73 4.29,-33.94 3.6,-18.82 8.59,-50.01 10.1,-68.92 2.03,-25.34 4.39,-46.63 5.74,-50.68 0.06,-0.18 0.14,-0.44 0.25,-0.76 5.03,-15.5 8.61,-31.48 10.44,-47.68 0.58,-5.12 1.11,-10.77 1.53,-16.84 1.84,-26.65 1,-41.15 5.77,-41.85 4.77,0.7 3.93,15.2 5.77,41.85 0.42,6.07 0.95,11.72 1.53,16.84 1.83,16.2 5.4,32.18 10.44,47.68 0.1,0.32 0.19,0.58 0.25,0.76 1.35,4.05 3.72,25.34 5.74,50.68 1.51,18.91 6.51,50.1 10.1,68.92 2.14,11.22 3.55,22.55 4.29,33.94 l 0.48,7.37 c 0,0 0.18,16.52 0.26,16.54 -0.51,3.97 -0.42,8.17 -0.2,10.37 0.38,3.67 4.43,5.18 5.82,9.61 1.39,4.43 0.51,15.3 2.4,19.47 1.9,4.17 1.64,5.06 3.92,9.86 2.28,4.8 6.7,6.51 10.43,5.06 3.73,-1.45 2.98,-4.49 2.98,-4.49 1,2.36 1.91,3.3 2.74,3.64 0.91,0.36 1.86,0.4 2.84,0.35 2.94,-0.15 3.9,-3.54 3.9,-3.54 3.79,1.04 5.58,-1.87 5.69,-3.41 0,0 1.23,0.13 2.21,-0.35 1.21,-0.58 2.09,-2.69 1.58,-4.68 0,0 0.68,0.58 2.02,-0.03 3.83,-1.74 -0.25,-7.84 -2.78,-10.37 -2.53,-2.53 -10.12,-14.42 -13.4,-20.74 -1.85,-3.55 -3.37,-7.65 -4.35,-10.57 -0.45,-1.33 -0.71,-2.69 -0.79,-4.09 -0.49,-7.96 -2.15,-36.88 -1.28,-48.19 1.01,-13.18 4.05,-31.76 4.73,-55.75 0.68,-23.99 1.53,-37.17 -0.15,-45.95 -1.69,-8.79 -6.08,-24.33 -7.43,-31.76 -0.36,-1.98 5.37,-59.02 6.95,-68.88 4.33,-27.01 2.28,-54.65 -0.35,-81.93 -1.18,-12.21 -3.8,-23.93 -6.4,-35.88 -2.35,-10.83 0,0 -7.54,-37.21 -4.29,-21.18 2.87,-42.65 9.83,-57.23 4.6,16.23 10.98,31.39 11.7,37.45 1.12,9.33 -1.49,16.8 5.97,38.44 5.8,16.81 14.75,44.43 18.45,55.93 l -0.13,0.02 c 0,0 1.92,5.34 2.87,9.43 0.94,4.09 2.21,16.57 3.08,22.68 0.88,6.11 2.96,12.37 4.47,19.16 0.93,4.2 2.23,10.14 3.53,12.39 1.14,1.97 2.3,2.3 3.63,2.14 2.11,-0.26 2.26,-3.43 1.44,-7.91 -0.65,-3.54 -2.66,-10.61 -2.76,-13.2 -0.05,-1.2 0.65,0.38 1.07,1.97 1.09,4.2 2.91,13.11 4.11,18.02 1.18,4.79 2.96,9.3 4.97,9.9 2.25,0.67 3.92,-0.78 3.93,-2.94 0,-2.73 -1.88,-7.13 -2.68,-10.51 -1.44,-6.05 -3.88,-18.82 -3.88,-18.82 0,0 3.79,15.22 5.07,20.76 0.12,0.53 1.82,6.05 3.19,9.37 1.36,3.28 3.78,5.46 5.83,3.74 3.89,-3.27 -0.67,-11.94 -2.43,-18.72 -1.76,-6.78 -4.15,-17.98 -4.15,-17.98 0,0 4.34,13.27 6.44,20.7 2.11,7.43 5.15,11.16 7.29,8.27 2.14,-2.89 1.08,-8.1 0.12,-10.93 -0.96,-2.83 -2.42,-8.38 -3.93,-13 -1.51,-4.62 -5.29,-18.33 -3.5,-18.87 1.8,-0.55 6.62,8.7 13.91,10.36 7.29,1.66 8.34,-4.01 5.15,-6.24 z"
        id="path184"
      />
      <path
        class="cls-120"
        d="m 346.42985,695.16789 c -2.09,6.36 -3.23,13.8 -7.53,19.52 -4.01,5.33 -9.64,11.04 -15.99,15.8 6.1,-3.18 13.41,-8.66 17.24,-14.32 3.69,-5.45 5.54,-11.51 6.29,-14.47 v -6.53 z"
        id="path186"
        style="fill: url(#linearGradient1352)"
      />
      <path
        class="cls-3"
        d="m 349.53985,712.38789 c 0.22,-0.52 0.42,-1.12 0.16,-1.63 -4.04,4.55 -8.28,9.19 -12.95,13.2 -4.82,4.14 -7.17,6.9 -13.07,10.69 5.34,-2.25 7.13,-4.33 11.43,-7.39 5.8,-4.12 11.76,-8.62 14.43,-14.87 z"
        id="path188"
        style="fill: url(#linear-gradient-2)"
      />
      <path
        class="cls-118"
        d="m 352.19985,712.92789 c -1.24,-0.07 -1.48,0.06 -2.08,1.06 -2.3,3.85 -3.93,5.59 -7.33,9.52 -1.31,1.51 -6.36,6.02 -7.77,7.45 -1.32,1.35 -2.73,2.63 -4.14,3.9 -1.35,1.23 -2.71,2.46 -4.06,3.69 8.46,-5.27 15.97,-11.82 22.13,-19.33 1.54,-1.88 3.05,-3.94 3.24,-6.3 z"
        id="path190"
        style="fill: url(#linear-gradient-3)"
      />
      <path
        class="cls-134"
        d="m 346.37985,728.01789 c 2.4,-4.03 4.41,-8.49 5.63,-12.92 0.29,-1.07 2.83,-9.19 2.83,-9.19 -0.81,-0.1 -1.84,3.14 -2.28,3.77 -0.44,0.63 -1.82,4.3 -2.03,5.02 -2.78,9.39 -10.37,21.69 -16.06,29.49 6.39,-5.63 11,-14.65 11.91,-16.17 z"
        id="path192"
        style="fill: url(#linear-gradient-4)"
      />
      <path
        class="cls-87"
        d="m 350.36985,715.61789 c 0.23,2 0.66,4.19 0.67,5.51 0.02,2.23 -0.37,7.23 -0.9,9.4 -1.03,4.23 -2.83,10.11 -5.41,14.42 3.3,-2.65 6.07,-11.08 6.83,-15.05 1.69,-8.74 0.94,-13.64 -0.06,-15.92 -0.32,0.58 -0.73,1.1 -1.14,1.62 z"
        id="path194"
        style="fill: url(#linear-gradient-5)"
      />
      <path
        class="cls-30"
        d="m 346.82985,716.96789 c 4,-4.82 5.47,-10.5 6.56,-16.47 1.8,-9.92 2.86,-18.67 1,-28.64 -0.89,-4.75 -1.84,-10.74 -3.2,-15.41 -6.99,-24 -4.77,-49.17 -2.51,-73.77 2,-21.74 4.13,-46.52 6.13,-68.27 -2.96,9.44 -3.98,22.35 -4.85,32.16 -1.24,14.02 -2.48,28.04 -3.73,42.05 -1.54,17.33 -3.07,34.79 -0.71,52.1 2.13,15.61 7.4,30.95 7.63,46.65 0.15,10.3 -2.19,20.05 -6.32,29.59 z"
        id="path196"
        style="fill: url(#linear-gradient-6)"
      />
      <path
        class="cls-103"
        d="m 358.66985,542.06789 c -1,2.48 -2,4.95 -3,7.43 -1.89,4.67 -3.81,9.54 -3.49,14.57 0.26,4.06 2.62,11.55 8.55,18.63 0.72,0.85 -0.96,-2.84 0,-2.68 -4.29,-8.52 -5.31,-9.39 -5.93,-13.16 -0.64,-3.85 -0.13,-9.67 0.84,-13.59 0.93,-3.76 1.94,-7.49 3.03,-11.2 z"
        id="path198"
        style="fill: url(#linear-gradient-7)"
      />
      <path
        class="cls-138"
        d="m 359.95985,607.24789 c -0.91,-6.02 -2.92,-11.81 -4.6,-17.65 -2.49,-8.62 -4.3,-17.42 -5.71,-26.28 -0.41,3.41 -0.6,3.78 -0.44,7.21 0.34,7.05 1.3,11.87 4.65,20.85 5.07,13.59 6.64,21.96 4.98,29.48 2.15,-3.58 1.75,-9.47 1.12,-13.6 z"
        id="path200"
        style="fill: url(#linear-gradient-8)"
      />
      <path
        class="cls-111"
        d="m 365.88985,611.40789 c -2.08,-24.98 1.21,-38.39 0.69,-51.9 -0.73,-18.83 -3.26,-25.72 -5.66,-45.11 -0.46,16.84 3.24,29.58 3.71,45.95 0.47,16.38 -3.04,35.25 1.27,51.06 z"
        id="path202"
        style="fill: url(#linear-gradient-9)"
      />
      <path
        class="cls-61"
        d="m 354.38985,700.49789 c -1.7,5.75 -2.72,11.13 -5.6,16.46 6.81,-8.05 7.71,-17.57 9.76,-27.57 0.97,-4.73 1.37,-9.56 1.72,-14.37 0.59,-8.13 1.09,-16.29 1.48,-24.48 1.4,-29.35 1.44,-58.99 -0.39,-88.2 -0.59,-9.38 -2.27,-27.16 -6.48,-35.39 5.87,28.01 5.1,66.45 4.75,94.87 -0.11,9.36 -0.36,18.71 -0.74,28.06 -0.45,11.16 -1.1,22.31 -1.93,33.45 -0.43,5.78 -0.92,11.59 -2.57,17.17 z"
        id="path204"
        style="fill: url(#linear-gradient-10)"
      />
      <path
        class="cls-47"
        d="m 353.00985,558.99789 c -1.63,5.96 -7.95,14.78 -10.12,20.57 -2.17,5.79 -3.48,12.25 -1.54,18.12 0.69,-2.86 0.53,-5.86 1.07,-8.76 0.85,-4.62 3.41,-8.71 5.4,-12.97 1.99,-4.26 6.73,-12.51 5.2,-16.96 z"
        id="path206"
        style="fill: url(#linear-gradient-11)"
      />
      <path
        class="cls-145"
        d="m 355.08985,602.26789 c 0.54,-2.2 1.17,-4.41 1.45,-6.65 -0.26,-0.43 -0.49,-0.88 -0.7,-1.34 -6.82,17.76 -6.44,38.19 1.26,55.6 -3.79,-14.87 -3.9,-15.46 -4.09,-23.54 -0.24,-10.11 0.18,-16.36 2.08,-24.08 z"
        id="path208"
        style="fill: url(#linear-gradient-12)"
      />
      <path
        class="cls-146"
        d="m 361.01985,611.40789 c -4.71,10.37 -7.47,15.99 -8.59,30.73 -0.62,8.19 -0.34,11.93 -4.01,26.48 -1.16,4.6 -1.9,9.31 -2.37,14.03 -0.62,6.27 0.14,12.59 0.05,18.89 -0.1,6.3 -0.26,12.81 -4.1,18.02 2.18,-2.89 1.96,-0.47 2.9,-2.61 2.42,-5.54 2.82,-11.78 2.42,-17.64 -0.3,-4.45 0.12,-13.35 0.65,-17.77 1.27,-10.71 3.27,-14.33 4.61,-20.5 2.33,-10.67 0.73,-21.28 3.37,-31.89 1.16,-4.65 3.21,-9.13 5.06,-13.63 v -4.12 z"
        id="path210"
        style="fill: url(#linear-gradient-13)"
      />
      <path
        class="cls-26"
        d="m 360.51985,545.05789 c -1.14,6.45 -1.56,13.11 -4.08,19.15 4.13,-5.05 5.06,-11.89 6.41,-18.27 1.97,-9.26 5.17,-18.26 9.48,-26.68 1.83,-3.57 3.89,-7.14 4.38,-11.12 -8.24,10.78 -13.85,23.55 -16.2,36.91 z"
        id="path212"
        style="fill: url(#linear-gradient-14)"
      />
      <path
        class="cls-16"
        d="m 354.81985,540.54789 c 3.64,-8.46 1.87,-18.13 0.76,-27.28 -1.26,-10.39 -1.56,-20.92 -0.41,-31.32 0.48,-4.36 1.16,-9.08 -1.02,-12.89 -2.14,17.81 -2.07,35.88 0.19,53.68 0.75,5.92 1.75,11.98 0.48,17.81 z"
        id="path214"
        style="fill: url(#linear-gradient-15)"
      />
      <path
        class="cls-68"
        d="m 385.28985,498.69789 c -0.44,3.44 -1.2,6.83 -1.96,10.22 6.17,-15.47 6.42,-33.01 1.87,-49.03 -1.07,12.91 1.74,25.96 0.09,38.81 z"
        id="path216"
        style="fill: url(#linear-gradient-16)"
      />
      <path
        class="cls-7"
        d="m 344.71985,429.16789 c -0.28,-1.09 -0.49,-2.2 -0.53,-3.36 -0.06,-1.65 -0.16,-3.31 -0.25,-4.96 -2.81,14.67 -2.59,29.91 0.83,44.45 -1.07,-17.47 -0.77,-27.17 -0.05,-36.13 z"
        id="path218"
        style="fill: url(#linear-gradient-17)"
      />
      <path
        class="cls-20"
        d="m 399.43985,319.86789 c 2.02,-1.08 4.41,-2.65 4.15,-4.92 -21.38,8.43 -38.22,27.56 -43.87,49.84 -3.35,13.21 -2.93,27.05 -2.49,40.67 1.15,35.51 2.29,71.02 3.44,106.53 0.15,4.6 0.3,9.24 1.44,13.7 1.58,-30.91 1.9,-61.88 0.96,-92.82 -0.21,-6.94 -0.49,-13.89 -1.28,-20.79 -0.8,-6.99 -2.13,-13.92 -2.5,-20.95 -1.49,-28.73 14.8,-57.65 40.15,-71.25 z"
        id="path220"
        style="fill: url(#linear-gradient-18)"
      />
      <path
        class="cls-131"
        d="m 385.92985,346.07789 c 2.43,-2.68 6.79,-7.91 9.69,-10.08 2.9,-2.17 9.44,-6 9.49,-9.62 -10.25,4.13 -22.47,17.74 -27.79,27.42 -4.45,8.11 -7.89,16.79 -10.13,25.76 -7.55,30.23 -1.36,62.1 6.61,92.23 2.11,7.95 4.35,15.97 4.59,24.19 3.5,-15.59 -2.29,-31.52 -5.87,-47.09 -2.14,-9.3 -3.5,-18.77 -4.73,-28.24 -0.64,-4.94 -1.25,-9.89 -1.27,-14.87 -0.09,-18.08 7.41,-35.23 14.78,-51.74 1.26,-2.82 2.55,-5.69 4.62,-7.97 z"
        id="path222"
        style="fill: url(#linear-gradient-19)"
      />
      <path
        class="cls-29"
        d="m 403.58985,348.38789 c 0.64,-0.67 1.02,-2.14 0.09,-2.19 -12,8.88 -20.49,22.4 -23.27,37.07 -0.92,4.86 -1.24,9.81 -1.55,14.75 -1.5,23.53 -3,47.07 -4.5,70.6 -0.34,5.37 -0.68,10.76 -0.47,16.14 0.47,11.64 3.55,23.23 2.18,34.8 5.84,-14.89 -0.08,-31.6 0.69,-47.57 0.34,-7.05 1.99,-13.98 2.84,-20.99 0.56,-4.66 0.76,-9.35 0.96,-14.04 0.72,-16.89 1.45,-33.78 2.17,-50.67 0.19,-4.42 0.39,-8.9 1.69,-13.12 3.1,-10.08 11.84,-17.17 19.16,-24.77 z"
        id="path224"
        style="fill: url(#linear-gradient-20)"
      />
      <path
        class="cls-82"
        d="m 404.23985,352.71789 c -7.72,5.97 -11.98,15.41 -14.66,24.81 -8.42,29.57 -3.94,61.14 -6.62,91.78 -1.86,21.33 -7.25,42.35 -15.88,61.93 1.85,-6.71 5.26,-12.85 8.12,-19.18 8.66,-19.17 9.56,-40.83 11.14,-61.82 1.58,-20.99 -0.38,-30.28 1.86,-51.22 1.44,-13.47 3.81,-26.31 7.83,-32.39 3.02,-4.57 8.01,-8.43 8.2,-13.92 z"
        id="path226"
        style="fill: url(#linear-gradient-21)"
      />
      <path
        class="cls-114"
        d="m 373.65985,560.87789 c -0.16,-4.34 -0.94,-8.64 -1.11,-12.99 -0.28,-6.74 1.79,-13.37 2.27,-20.1 0.14,-1.93 -0.66,-9.27 -1.87,-11.52 -0.41,-0.76 -1.08,1.78 -1.08,1.78 2.98,10.62 -1.76,22.13 -1.09,30.39 0.97,12.04 2.76,26.65 -3.69,39.22 5.16,-7.84 6.92,-17.39 6.58,-26.78 z"
        id="path228"
        style="fill: url(#linear-gradient-22)"
      />
      <path
        class="cls-130"
        d="m 369.44985,522.68789 c 0,-0.07 -0.02,-0.14 -0.02,-0.22 -0.61,1.58 -1.48,3.05 -2.61,4.3 1.3,17.15 -1.89,34.63 -1.82,51.95 0.08,21.21 5.02,43.35 -2.86,63.05 5.01,-7.98 6.42,-17.73 6.3,-27.15 -0.12,-9.42 -1.65,-18.77 -2.02,-28.18 -0.84,-21.28 4.24,-42.5 3.03,-63.76 z"
        id="path230"
        style="fill: url(#linear-gradient-23)"
      />
      <path
        class="cls-107"
        d="m 349.84985,386.42789 c 1.78,-7.98 4.91,-19.16 8.4,-26.54 4.78,-10.1 11.58,-26.68 22.53,-37.74 5.21,-5.26 15.83,-15.41 25.1,-20.42 -0.08,-1.24 -0.07,-2.49 0.12,-3.71 -19.76,7.97 -35.97,29.17 -45.21,48.35 -10.29,21.36 -16.94,44.71 -17.36,68.41 -0.62,34.45 11.09,67.27 29.1,98.76 4.01,7.01 5.58,14.57 5.82,22.64 3.25,-7.34 1.03,-16.02 -2.83,-23.06 -3.86,-7.04 -18.71,-36.2 -20.45,-44.48 -1.34,-6.37 -9.4,-35.38 -8.54,-57.93 0.36,-9.43 1.8,-17.53 3.3,-24.27 z"
        id="path232"
        style="fill: url(#linear-gradient-24)"
      />
      <path
        class="cls-84"
        d="m 362.69985,399.10789 c -1.83,-4.35 -3.68,-8.76 -4.3,-13.39 -0.78,-5.86 0.47,-11.79 2.04,-17.52 3.14,-11.4 7.72,-22.62 15.13,-32.24 2.9,-3.77 6.23,-7.28 8.7,-11.29 3.12,-5.07 4.78,-10.77 6.24,-16.43 1.9,-7.37 4.29,-13.14 5.64,-20.6 1.23,-6.8 11.65,-19.02 12.22,-19.95 0.57,-0.93 0.85,-4.44 -0.31,-4.59 -5.97,6.51 -11.68,13.81 -14.8,21.79 -2.07,5.3 -5.15,20.13 -6.71,25.58 -3.63,12.65 -13.08,20.2 -19.18,32.04 -6.65,12.92 -9.5,20.67 -10.87,34.87 -0.62,6.39 -0.66,12.91 0.98,19.15 1.4,5.33 5.49,10.57 7.75,15.65 3.5,7.88 6.76,14.83 6.64,24.11 3.66,-5.42 1.24,-12.41 -1.26,-18.36 -2.64,-6.27 -5.28,-12.54 -7.92,-18.82 z"
        id="path234"
        style="fill: url(#linear-gradient-25)"
      />
      <path
        class="cls-147"
        d="m 377.47985,286.72789 c 4.32,-3.45 8.19,-7.43 12.04,-11.39 2.22,-2.27 4.47,-4.6 5.84,-7.47 1.46,-3.05 3.87,-7.1 5.97,-9.76 1.26,-1.6 3.04,-2.74 4.19,-4.42 1.14,-1.68 1.35,-4.34 -0.34,-5.47 -4.1,3.97 -7.57,8.58 -10.25,13.62 -1.77,3.35 -5.2,7.37 -7.34,10.5 -4.61,6.76 -12,10.96 -18.52,15.91 -6.51,4.95 -12.71,11.69 -12.96,19.87 2.19,-5.39 5.14,-7.81 8.43,-11.12 3.88,-3.91 8.62,-6.84 12.93,-10.28 z"
        id="path236"
        style="fill: url(#linear-gradient-26)"
      />
      <path
        class="cls-121"
        d="m 406.08985,247.84789 c -8.53,4.82 -16.07,11.37 -22.04,19.15 -1.86,2.42 -3.63,5.18 -3.59,8.23 0,0 5.13,-5.34 7.91,-8.41 2.16,-2.39 12.61,-9.76 14.45,-11.74 1.85,-1.98 3.27,-4.52 3.26,-7.22 z"
        id="path238"
        style="fill: url(#linear-gradient-27)"
      />
      <path
        class="cls-25"
        d="m 402.86985,273.46789 c -6.66,3.71 -16.61,11.75 -22.6,16.01 -5.6,3.99 -8.12,8.86 -9.98,16.48 -0.94,3.83 -1.94,7.42 -7.04,11.85 2.14,-0.56 6.12,-2.96 6.91,-5.02 0.79,-2.06 2,-4.8 2.51,-6.95 1.08,-4.63 3.53,-8.94 6.96,-12.25 2.85,-2.75 20.72,-14.57 23.17,-16.35 0.03,-0.02 0.05,-0.04 0.08,-0.06 v -3.72 z"
        id="path240"
        style="fill: url(#linear-gradient-28)"
      />
      <path
        class="cls-127"
        d="m 388.19985,298.35789 c 2.14,-1.05 6.36,-4.56 8.11,-6.18 5.28,-4.89 7.5,-7.34 7.5,-7.34 0.2,-1.57 0.65,-2.3 1.56,-3.61 -5.93,4.22 -14.43,12.05 -20.37,16.27 -2.13,1.51 -4.29,3.06 -5.83,5.17 -1.48,2.04 -2.31,4.56 -2.32,7.08 1.81,-7.21 8.93,-10.21 11.34,-11.39 z"
        id="path242"
        style="fill: url(#linear-gradient-29)"
      />
      <path
        class="cls-128"
        d="m 313.14985,291.01789 c 0,-1.26 0.22,-2.48 0.54,-3.68 -4.38,3.64 -8.98,7.58 -12.62,10.17 -2.13,1.51 -4.29,3.06 -5.83,5.17 -1.48,2.04 -2.31,4.56 -2.32,7.08 1.81,-7.21 8.92,-10.21 11.34,-11.39 2.14,-1.05 6.36,-4.56 8.11,-6.18 0.29,-0.27 0.54,-0.5 0.81,-0.76 0,-0.13 -0.04,-0.27 -0.04,-0.4 z"
        id="path244"
        style="fill: url(#linear-gradient-30)"
      />
      <path
        class="cls-69"
        d="m 398.43985,317.95789 c 1.5,-0.81 3.14,-1.47 4.33,-2.7 1.19,-1.23 1.75,-3.29 0.72,-4.65 -6.09,1.78 -11.33,5.87 -15.37,10.77 -4.04,4.9 -6.99,10.59 -9.66,16.35 -8.52,18.38 -14.55,38.49 -12.94,58.67 0.65,8.16 2.55,16.3 1.79,24.45 5.09,-16.69 -0.47,-35.03 3.58,-52 1.21,-5.08 3.26,-9.91 5.29,-14.71 1.84,-4.33 3.67,-8.66 5.51,-12.99 3.8,-8.96 8.18,-18.58 16.75,-23.19 z"
        id="path246"
        style="fill: url(#linear-gradient-31)"
      />
      <path
        class="cls-44"
        d="m 395.01985,386.48789 c 0.31,-4.77 0.79,-10.05 2.2,-14.62 1.87,-6.09 3.79,-12.28 7.34,-17.58 1.25,2.59 0.9,5.68 -0.03,8.4 -0.93,2.72 -2.38,5.24 -3.32,7.95 -1.08,3.12 -2.39,8.38 -2.76,11.66 -0.95,8.46 -0.95,15.22 1.33,23.41 -4.1,-5.71 -5.22,-12.21 -4.77,-19.22 z"
        id="path248"
        style="fill: url(#linear-gradient-32)"
      />
      <path
        class="cls-124"
        d="m 390.32985,398.47789 c -1.2,-8.17 -0.15,-16.54 1.87,-24.54 2.2,-8.71 6.04,-17.74 13.74,-22.36 0,0 -3.4,6.31 -6.25,11.11 -7.65,12.87 -9.95,33.53 -4.14,47.33 -3.22,-2.86 -4.6,-7.27 -5.23,-11.53 z"
        id="path250"
        style="fill: url(#linear-gradient-33)"
      />
      <path
        class="cls-96"
        d="m 384.08985,368.48789 c -0.56,3.97 -0.23,8.44 2.55,11.34 -0.52,-3.74 -1.04,-7.51 -0.73,-11.27 0.31,-3.76 2.24,-7.04 4.08,-10.33 4.29,-7.68 14.4,-16.33 14.05,-17.02 -0.35,-0.69 -1.47,-0.99 -1.9,-0.35 -1.78,1.78 -3.57,3.55 -5.35,5.33 -2.21,2.2 -4.42,4.41 -6.3,6.9 -3.39,4.49 -5.61,9.84 -6.39,15.41 z"
        id="path252"
        style="fill: url(#linear-gradient-34)"
      />
      <path
        class="cls-42"
        d="m 381.65985,358.54789 c -5.54,9.16 -8.64,20.63 -4.79,30.62 0,0 0.01,-9.2 0.63,-13.86 0.89,-6.77 4.94,-12.77 8.84,-18.68 6.87,-10.42 21.57,-23.73 19.51,-25.53 -1.21,0.74 -2.42,1.47 -3.63,2.21 0,0 -15.03,16.09 -20.57,25.25 z"
        id="path254"
        style="fill: url(#linear-gradient-35)"
      />
      <path
        class="cls-27"
        d="m 402.83985,323.21789 c -0.05,1.4 0.11,-2.8 0.16,-4.2 -0.51,-0.48 -1.34,-0.11 -1.92,0.29 -9.38,6.49 -16.31,18.97 -16.45,30.37 0,0 3.47,-10.79 4.4,-12.56 4.79,-9.14 13.84,-14.67 13.81,-13.9 z"
        id="path256"
        style="fill: url(#linear-gradient-36)"
      />
      <path
        class="cls-66"
        d="m 394.32985,247.43789 c -3.53,2.36 -7.42,4.21 -10.66,6.95 -3.24,2.74 -5.87,6.67 -5.65,10.91 3.87,-4.76 7.81,-9.59 12.87,-13.06 3.33,-2.29 7.09,-3.94 10.23,-6.49 3.14,-2.55 5.68,-6.36 5.23,-10.38 -3.17,4.76 -7.28,8.89 -12.03,12.07 z"
        id="path258"
        style="fill: url(#linear-gradient-37)"
      />
      <path
        class="cls-125"
        d="m 397.34985,237.70789 c 2.09,-1.35 4.14,-2.76 6.08,-4.32 1.08,-0.86 2.14,-1.8 2.81,-3 0.67,-1.21 0.9,-2.66 0.62,-4.02 -3.2,4.99 -8.51,8.2 -13.81,10.86 -5.3,2.66 -10.87,5.02 -15.3,8.96 -4.43,3.95 -7.57,9.97 -6.27,15.75 1.68,-5.82 5.87,-10.62 10.63,-14.36 4.76,-3.74 10.14,-6.6 15.23,-9.87 z"
        id="path260"
        style="fill: url(#linear-gradient-38)"
      />
      <path
        class="cls-55"
        d="m 361.61985,255.03789 c 4.76,-8.47 13.15,-14.17 21.23,-19.55 5.8,-3.87 11.61,-7.73 17.41,-11.6 2.63,-1.75 5.55,-4.01 5.58,-7.16 -13.28,7.32 -26.76,14.79 -37.47,25.53 -3.5,3.51 -6.86,7.83 -6.76,12.79 z"
        id="path262"
        style="fill: url(#linear-gradient-39)"
      />
      <path
        class="cls-22"
        d="m 391.43985,214.58789 c -7.01,3.74 -14.64,6.34 -21.23,10.77 -6.6,4.42 -12.26,11.3 -12.45,19.24 8.65,-15.12 24.89,-24.11 40.8,-31.19 2.19,-0.98 4.45,-1.96 6.19,-3.61 1.75,-1.65 2.91,-4.13 2.34,-6.47 -4.69,4.43 -9.96,8.23 -15.65,11.26 z"
        id="path264"
        style="fill: url(#linear-gradient-40)"
      />
      <path
        class="cls-79"
        d="m 397.75985,203.95789 c 1.94,-1.26 3.71,-2.77 5.48,-4.26 2.17,-1.84 4.53,-4.82 2.92,-7.17 -7.57,8 -18.12,12.3 -27.92,17.34 -9.8,5.03 -19.69,11.66 -23.78,21.88 9.84,-9.54 21.32,-17.37 33.78,-23.05 3.23,-1.47 6.54,-2.81 9.51,-4.74 z"
        id="path266"
        style="fill: url(#linear-gradient-41)"
      />
      <path
        class="cls-116"
        d="m 353.58985,221.48789 c 13.24,-13.29 32.02,-19.07 48.54,-27.97 0.95,-0.51 1.92,-1.05 2.66,-1.84 1.34,-1.42 1.77,-3.63 1.07,-5.46 -13.59,10.98 -31.73,14.99 -45.55,25.69 -3.17,2.46 -6.27,5.6 -6.72,9.58 z"
        id="path268"
        style="fill: url(#linear-gradient-42)"
      />
      <path
        class="cls-13"
        d="m 407.38985,178.70789 c -0.56,-0.19 -1.13,-0.38 -1.69,-0.57 -13.65,11.67 -32.6,14.75 -48.09,23.84 -2.82,1.65 -5.81,3.99 -5.94,7.25 14.98,-10.42 33.28,-14.89 49.2,-23.81 2.8,-1.57 5.76,-3.59 6.53,-6.71 z"
        id="path270"
        style="fill: url(#linear-gradient-43)"
      />
      <path
        class="cls-140"
        d="m 396.47985,177.98789 c 4.23,-1.36 9.06,-3.15 10.5,-7.35 -14.87,8.96 -32.83,11.43 -48.16,19.59 -2.77,1.48 -5.68,3.44 -6.44,6.49 14.1,-7.54 28.88,-13.81 44.09,-18.72 z"
        id="path272"
        style="fill: url(#linear-gradient-44)"
      />
      <path
        class="cls-92"
        d="m 399.23985,167.44789 c 1.56,-0.7 3.12,-1.4 4.62,-2.21 0.68,-0.36 1.36,-0.77 1.82,-1.38 0.58,-0.78 0.72,-1.87 0.36,-2.77 -7.75,4.32 -16.53,6.33 -24.88,9.32 -8.35,3 -16.72,7.36 -21.53,14.81 13.2,-5.92 26.41,-11.84 39.61,-17.77 z"
        id="path274"
        style="fill: url(#linear-gradient-45)"
      />
      <path
        class="cls-143"
        d="m 406.31985,147.22789 c -3.9,3.55 -8.37,6.53 -13.2,8.8 -12.61,5.92 -27.01,6.81 -40.92,8.55 -13.91,1.74 -28.45,4.78 -38.82,13.86 7.49,-2.9 15.02,-5.81 22.88,-7.56 16.86,-3.76 34.67,-2.07 51.49,-6 4.64,-1.08 9.28,-2.65 12.95,-5.59 3.66,-2.94 6.21,-7.49 5.63,-12.04 z"
        id="path276"
        style="fill: url(#linear-gradient-46)"
      />
      <path
        class="cls-142"
        d="m 391.97985,109.53789 c -0.06,-1.04 -0.12,-2.11 0.2,-3.1 0.31,-0.94 0.94,-1.73 1.55,-2.51 2.1,-2.64 4.27,-5.330004 7.15,-7.090004 1.4,-0.85 2.96,-1.49 4.1,-2.66 1.14,-1.17 1.7,-3.15 0.69,-4.44 -5.36,2.42 -10.84,5.13 -14.52,9.72 -3.68,4.590004 -5.03,11.570004 -1.59,16.340004 1.74,2.41 4.46,3.96 7.3,4.8 2.84,0.84 5.84,1.03 8.8,1.15 -0.85,-2.42 -3.61,-3.52 -6.09,-4.19 -2.48,-0.67 -5.25,-1.4 -6.59,-3.59 -0.8,-1.31 -0.91,-2.91 -1,-4.44 z"
        id="path278"
        style="fill: url(#linear-gradient-47)"
      />
      <path
        class="cls-43"
        d="m 403.23985,109.95789 c 1.55,-0.61 2.39,-2.36 3.22,-3.8 0.83,-1.44 1.04,-3.45 -0.11,-4.65 -7.68,4.57 -11.23,13.95 -11.94,22.86 -0.71,8.91 0.84,17.85 0.67,26.79 -0.22,11.7 -0.71,44.19 -0.13,48.82 0.9,7.14 0.5,14.38 1.18,21.54 0.68,7.16 2.61,14.52 7.4,19.88 2.57,-2.23 3.12,-6.43 1.23,-9.24 -0.51,-0.76 -1.17,-1.42 -1.62,-2.22 -0.68,-1.21 -0.75,-3.24 -1.54,-2.1 -4.03,5.85 -4.32,-56.61 -3.5,-66.59 0.71,-8.6 -5.1,-47.27 5.16,-51.29 z"
        id="path280"
        style="fill: url(#linear-gradient-48)"
      />
      <path
        class="cls-65"
        d="m 339.67985,148.04789 c 11.4,1.79 21.16,-1.97 31.61,-5.55 10.45,-3.58 33.23,-16.46 33.9,-17.94 1.07,-2.38 -1.97,0.26 -0.35,-1.97 -10.73,5.54 -17.27,9.4 -27.78,13.96 -10.97,4.75 -23.9,11.14 -37.38,11.51 z"
        id="path282"
        style="fill: url(#linear-gradient-49)"
      />
      <path
        class="cls-48"
        d="m 406.20985,129.46789 c -11.93,6.29 -23.93,12.61 -37.26,17.4 -13.33,4.79 -28.2,8.02 -43.25,7.66 8.05,3.95 19.22,2.41 28.55,0.12 13.03,-3.21 25.4,-7.56 37.33,-12.37 7.2,-2.91 15.15,-7.1 14.63,-12.81 z"
        id="path284"
        style="fill: url(#linear-gradient-50)"
      />
      <path
        class="cls-5"
        d="m 391.57985,147.22789 c 1.54,-2.99 4.55,-7.25 6.56,-10.57 -0.43,-1.12 -0.75,-2.28 -0.92,-3.47 -9.14,11.68 -14.07,26.32 -15.88,41.07 -1.89,15.46 -0.62,31.14 1.23,46.61 0.7,5.92 1.47,12.07 -0.4,17.73 -1.5,4.53 -5.04,13.47 -3.58,18.01 0.05,-4.76 3.98,-13 6.18,-17.21 4.19,-8.06 -0.17,-26.46 -0.67,-35.53 -0.83,-14.86 -1.16,-21.09 1.48,-35.94 0.94,-5.29 3.55,-15.91 6.01,-20.68 z"
        id="path286"
        style="fill: url(#linear-gradient-51)"
      />
      <path
        class="cls-24"
        d="m 347.89985,164.60789 c -3.34,1.88 -6.74,3.72 -9.65,6.21 -3.41,2.92 -6.02,6.66 -8.31,10.53 -5.06,8.58 -8.67,18.01 -10.62,27.78 -3.42,17.16 -12.05,52.41 -20.21,70.49 10.57,-16.62 19.94,-49.37 22.72,-64.98 2.78,-15.61 7.9,-31.88 20.1,-42.01 6.02,-5 13.34,-8.13 20.12,-12.03 4.46,-2.56 8.71,-5.48 12.95,-8.39 4.34,-2.98 8.68,-5.95 13.02,-8.92 6.26,-4.3 13.16,-9.67 13.56,-17.25 -16.41,14.78 -34.44,27.74 -53.68,38.58 z"
        id="path288"
        style="fill: url(#linear-gradient-52)"
      />
      <path
        class="cls-33"
        d="m 351.29985,175.27789 c -1.47,-1.19 -2.4,-0.03 -2.51,1.93 -0.3,5.51 -5.3,17.34 -8.38,21.78 -4.06,5.86 -8.81,10.68 -10.96,17.59 -2.15,6.91 -2.17,14.91 1.5,21.05 -1.17,-14.77 0.94,-17.57 1.94,-21.02 0.5,-1.72 1.4,-3.27 2.34,-4.76 3.58,-5.72 7.72,-11.05 10.96,-17 3.24,-5.94 5.59,-12.71 5.09,-19.56 z"
        id="path290"
        style="fill: url(#linear-gradient-53)"
      />
      <path
        class="cls-91"
        d="m 306.86985,338.55789 c 3.31,-9.02 6.98,-19.6 9.77,-28.8 7.29,-24.06 8.86,-45.67 8.5,-71.69 -0.38,-27.2 1.95,-44.26 24.63,-60.91 8.52,-6.25 45.38,-27.94 55.86,-29.26 0.62,-1.6 -0.09,-3.61 -1.59,-4.46 -16.82,10.21 -62.67,28.45 -72.66,45.41 -9.47,16.09 -9.12,28.36 -9.34,47.03 -0.14,11.62 0.1,17.88 -1.16,34.47 -0.77,10.1 -2.04,17.02 -3.67,27.02 -1.18,7.23 -3.61,14.18 -6.04,21.09 -7.45,21.23 -14.46,48.24 -20.4,64.65 -4.52,12.49 -3.5,21.14 -8.22,41.14 7.02,-18.26 3.76,-28.31 9.61,-40.09 3.04,-6.12 11.63,-37.25 14.7,-45.61 z"
        id="path292"
        style="fill: url(#linear-gradient-54)"
      />
      <path
        class="cls-94"
        d="m 276.56985,375.87789 c -0.27,0.11 -0.54,0.22 -0.81,0.32 -3.67,1.4 -7.14,3.32 -10.28,5.68 -3.19,2.4 -5.89,5.62 -9.5,7.43 3.91,0.3 8.24,-4.9 12.14,-7.57 3.98,-2.73 8.73,-4.58 13.71,-7.08 2.26,-1.13 6.76,-3.95 9.21,-7.02 1.41,-1.76 1.16,-3.77 1.9,-5.15 -3.38,6.33 -9.83,10.75 -16.37,13.39 z"
        id="path294"
        style="fill: url(#linear-gradient-55)"
      />
      <path
        class="cls-21"
        d="m 278.19985,386.05789 c -1.59,2.09 -5.01,6.42 -6.37,8.67 -4.09,6.77 -5.32,12.96 -6.98,22.63 2.23,-8.07 4.55,-16.32 9.35,-23.13 3.15,-4.46 6.18,-8.95 9.18,-13.52 2.55,-3.88 7.32,-10.18 7.98,-14.81 -3.71,7.51 -8.19,13.64 -13.16,20.15 z"
        id="path296"
        style="fill: url(#linear-gradient-56)"
      />
      <path
        class="cls-141"
        d="m 276.25985,407.77789 c -0.58,5.89 -1.22,11.79 -1.61,17.69 2.99,-7.8 1.99,-22.09 5.03,-29.87 0.81,-2.07 1.93,-4.01 2.94,-6 2.72,-5.37 3.74,-7.62 4.72,-13.56 -3.29,10.68 -6.54,13.15 -8.21,18.09 -1.25,3.69 -2.26,7.39 -2.62,11.26 -0.08,0.8 -0.15,1.59 -0.23,2.39 z"
        id="path298"
        style="fill: url(#linear-gradient-57)"
      />
      <path
        class="cls-17"
        d="m 286.82985,377.62789 c 0.69,8.99 -0.52,11.19 -3.18,17.38 -1.5,3.48 -1.5,11.72 -0.75,19.56 -0.17,-0.7 0.06,-10.19 0.75,-15.76 0.46,-3.72 3.24,-8.08 3.94,-11.77 0.63,-3.27 0.71,-6.76 -0.45,-9.85 -0.1,0.14 -0.2,0.29 -0.3,0.43 z"
        id="path300"
        style="fill: url(#linear-gradient-58)"
      />
      <path
        class="cls-62"
        d="m 294.77985,373.92789 c -0.17,4.35 0.32,6.78 -0.37,19.92 -0.35,6.6 -1.34,14.36 -1.48,20.73 1.42,-9.68 3.94,-25.61 2.83,-40.88 -0.31,0.11 -0.65,0.16 -0.99,0.23 z"
        id="path302"
        style="fill: url(#linear-gradient-59)"
      />
      <path
        class="cls-36"
        d="m 404.52985,306.02789 c -14.39,5.79 -28.77,12.21 -40.79,22.02 -12.02,9.81 -21.57,23.48 -23.44,38.88 8.57,-21.11 26,-38.47 47.15,-46.95 3.59,-1.44 7.32,-2.66 10.56,-4.77 3.24,-2.12 6.01,-5.34 6.51,-9.18 z"
        id="path304"
        style="fill: url(#linear-gradient-60)"
      />
      <path
        class="cls-73"
        d="m 343.14985,709.00789 c 0.53,-0.69 1.04,-1.66 0.53,-2.37 -2.58,3.38 -5.71,6.35 -9.23,8.74 -1.38,0.94 -2.84,1.8 -3.96,3.04 4.97,-1.91 9.4,-5.2 12.65,-9.41 z"
        id="path306"
        style="fill: url(#linear-gradient-61)"
      />
      <path
        class="cls-77"
        d="m 359.26985,688.49789 c -0.2,-1.6 -0.39,-3.21 -0.35,-4.82 0.08,-2.75 0.78,-5.82 -0.86,-8.03 -0.56,9.91 0.55,19.91 3.25,29.46 -0.68,-5.54 -1.36,-11.07 -2.04,-16.61 z"
        id="path308"
        style="fill: url(#linear-gradient-62)"
      />
      <path
        class="cls-51"
        d="m 356.38985,711.64789 c -0.61,-2.11 -0.94,-7.55 -0.34,-11.76 -0.98,0.85 -1.16,2.76 -1.21,4.06 -0.16,4.44 0.72,10.1 1.5,14.48 0.25,-1.12 0.36,-5.66 0.05,-6.77 z"
        id="path310"
        style="fill: url(#linear-gradient-63)"
      />
      <path
        class="cls-88"
        d="m 345.68985,699.11789 c -2.24,2.66 -4.53,5.37 -7.42,7.31 2.59,-0.92 4.62,-2.92 6.56,-4.87 0.24,-0.24 0.49,-0.49 0.63,-0.79 0.24,-0.5 0.19,-1.09 0.22,-1.65 z"
        id="path312"
        style="fill: url(#linear-gradient-64)"
      />
      <path
        class="cls-98"
        d="m 350.73985,534.87789 c 0.4,-0.68 0.81,-1.36 1.05,-2.11 0.32,-0.98 0.34,-2.04 0.35,-3.07 -6.59,8.5 -10.26,19.21 -10.28,29.96 1.4,-8.71 4.43,-17.16 8.88,-24.78 z"
        id="path314"
        style="fill: url(#linear-gradient-65)"
      />
      <path
        class="cls-105"
        d="m 464.34985,695.16789 c 2.09,6.36 3.23,13.8 7.53,19.52 4.01,5.33 9.63,11.04 15.99,15.8 -6.1,-3.18 -13.41,-8.66 -17.24,-14.32 -3.69,-5.45 -5.54,-11.51 -6.29,-14.47 v -6.53 z"
        id="path316"
        style="fill: url(#linear-gradient-66)"
      />
      <path
        class="cls-52"
        d="m 461.22985,712.38789 c -0.22,-0.52 -0.42,-1.12 -0.16,-1.63 4.04,4.55 8.28,9.19 12.95,13.2 4.82,4.14 7.17,6.9 13.07,10.69 -5.34,-2.25 -7.13,-4.33 -11.43,-7.39 -5.8,-4.12 -11.76,-8.62 -14.43,-14.87 z"
        id="path318"
        style="fill: url(#linear-gradient-67)"
      />
      <path
        class="cls-75"
        d="m 458.56985,712.92789 c 1.24,-0.07 1.48,0.06 2.08,1.06 2.3,3.85 3.93,5.59 7.33,9.52 1.31,1.51 6.36,6.02 7.77,7.45 1.32,1.35 2.73,2.63 4.14,3.9 1.35,1.23 2.71,2.46 4.06,3.69 -8.46,-5.27 -15.97,-11.82 -22.13,-19.33 -1.54,-1.88 -3.05,-3.94 -3.24,-6.3 z"
        id="path320"
        style="fill: url(#linear-gradient-68)"
      />
      <path
        class="cls-18"
        d="m 464.38985,728.01789 c -2.4,-4.03 -4.41,-8.49 -5.63,-12.92 -0.29,-1.07 -2.83,-9.19 -2.83,-9.19 0.81,-0.1 1.84,3.14 2.28,3.77 0.44,0.63 1.82,4.3 2.03,5.02 2.78,9.39 10.37,21.69 16.06,29.49 -6.39,-5.63 -11,-14.65 -11.91,-16.17 z"
        id="path322"
        style="fill: url(#linear-gradient-69)"
      />
      <path
        class="cls-99"
        d="m 460.40985,715.61789 c -0.23,2 -0.66,4.19 -0.67,5.51 -0.02,2.23 0.37,7.23 0.9,9.4 1.03,4.23 2.83,10.11 5.41,14.42 -3.3,-2.65 -6.07,-11.08 -6.83,-15.04 -1.69,-8.74 -0.94,-13.64 0.06,-15.92 0.32,0.58 0.73,1.1 1.14,1.62 z"
        id="path324"
        style="fill: url(#linear-gradient-70)"
      />
      <path
        class="cls-132"
        d="m 463.94985,716.96789 c -4,-4.82 -5.47,-10.5 -6.56,-16.47 -1.8,-9.92 -2.86,-18.67 -1,-28.64 0.89,-4.75 1.84,-10.74 3.2,-15.41 6.99,-24 4.77,-49.17 2.51,-73.77 -2,-21.74 -4.13,-46.52 -6.13,-68.27 2.96,9.44 3.98,22.35 4.85,32.16 1.24,14.02 2.48,28.04 3.73,42.05 1.54,17.33 3.07,34.79 0.71,52.1 -2.13,15.61 -7.4,30.95 -7.63,46.65 -0.15,10.3 2.19,20.05 6.32,29.59 z"
        id="path326"
        style="fill: url(#linear-gradient-71)"
      />
      <path
        class="cls-83"
        d="m 452.09985,542.06789 c 1,2.48 2,4.95 3,7.43 1.89,4.67 3.81,9.54 3.49,14.57 -0.26,4.06 -2.62,11.55 -8.55,18.63 -0.72,0.85 0.96,-2.84 0,-2.68 4.29,-8.52 5.31,-9.39 5.93,-13.16 0.64,-3.85 0.13,-9.67 -0.84,-13.59 -0.93,-3.76 -1.94,-7.49 -3.03,-11.2 z"
        id="path328"
        style="fill: url(#linear-gradient-72)"
      />
      <path
        class="cls-108"
        d="m 450.81985,607.24789 c 0.91,-6.02 2.92,-11.81 4.6,-17.65 2.49,-8.62 4.3,-17.42 5.71,-26.28 0.41,3.41 0.6,3.78 0.44,7.21 -0.34,7.05 -1.3,11.87 -4.65,20.85 -5.07,13.59 -6.64,21.96 -4.98,29.48 -2.15,-3.58 -1.75,-9.47 -1.12,-13.6 z"
        id="path330"
        style="fill: url(#linear-gradient-73)"
      />
      <path
        class="cls-115"
        d="m 444.87985,611.40789 c 2.08,-24.98 -1.21,-38.39 -0.69,-51.9 0.73,-18.83 3.26,-25.72 5.66,-45.11 0.46,16.84 -3.24,29.58 -3.71,45.95 -0.47,16.38 3.04,35.25 -1.27,51.06 z"
        id="path332"
        style="fill: url(#linear-gradient-74)"
      />
      <path
        class="cls-1"
        d="m 456.37985,700.49789 c 1.7,5.75 2.72,11.13 5.6,16.46 -6.81,-8.05 -7.71,-17.57 -9.76,-27.57 -0.97,-4.73 -1.37,-9.56 -1.72,-14.37 -0.59,-8.13 -1.09,-16.29 -1.48,-24.48 -1.4,-29.35 -1.44,-58.99 0.39,-88.2 0.59,-9.38 2.27,-27.16 6.48,-35.39 -5.87,28.01 -5.1,66.45 -4.75,94.87 0.11,9.36 0.36,18.71 0.74,28.06 0.45,11.16 1.1,22.31 1.93,33.45 0.43,5.78 0.92,11.59 2.57,17.17 z"
        id="path334"
        style="fill: url(#linear-gradient-75)"
      />
      <path
        class="cls-80"
        d="m 457.75985,558.99789 c 1.63,5.96 7.95,14.78 10.12,20.57 2.17,5.79 3.48,12.25 1.54,18.12 -0.69,-2.86 -0.53,-5.86 -1.07,-8.76 -0.85,-4.62 -3.42,-8.71 -5.4,-12.97 -1.98,-4.26 -6.73,-12.51 -5.2,-16.96 z"
        id="path336"
        style="fill: url(#linear-gradient-76)"
      />
      <path
        class="cls-135"
        d="m 455.67985,602.26789 c -0.54,-2.2 -1.17,-4.41 -1.45,-6.65 0.26,-0.43 0.49,-0.88 0.71,-1.34 6.82,17.76 6.44,38.19 -1.26,55.6 3.79,-14.87 3.9,-15.46 4.09,-23.54 0.24,-10.11 -0.18,-16.36 -2.08,-24.08 z"
        id="path338"
        style="fill: url(#linear-gradient-77)"
      />
      <path
        class="cls-28"
        d="m 449.74985,611.40789 c 4.71,10.37 7.47,15.99 8.58,30.73 0.62,8.19 0.34,11.93 4.01,26.48 1.16,4.6 1.9,9.31 2.37,14.03 0.62,6.27 -0.14,12.59 -0.05,18.89 0.1,6.3 0.26,12.81 4.1,18.02 -2.18,-2.89 -1.96,-0.47 -2.9,-2.61 -2.42,-5.54 -2.82,-11.78 -2.42,-17.64 0.3,-4.45 -0.12,-13.35 -0.65,-17.77 -1.27,-10.71 -3.27,-14.33 -4.61,-20.5 -2.33,-10.67 -0.73,-21.28 -3.37,-31.89 -1.16,-4.65 -3.21,-9.13 -5.06,-13.63 v -4.12 z"
        id="path340"
        style="fill: url(#linear-gradient-78)"
      />
      <path
        class="cls-100"
        d="m 450.24985,545.05789 c 1.14,6.45 1.56,13.11 4.08,19.15 -4.13,-5.05 -5.06,-11.89 -6.41,-18.27 -1.97,-9.26 -5.17,-18.26 -9.48,-26.68 -1.83,-3.57 -3.89,-7.14 -4.38,-11.12 8.24,10.78 13.85,23.55 16.2,36.91 z"
        id="path342"
        style="fill: url(#linear-gradient-79)"
      />
      <path
        class="cls-11"
        d="m 455.94985,540.54789 c -3.64,-8.46 -1.87,-18.13 -0.76,-27.28 1.26,-10.39 1.56,-20.92 0.41,-31.32 -0.48,-4.36 -1.15,-9.08 1.02,-12.89 2.14,17.81 2.07,35.88 -0.19,53.68 -0.75,5.92 -1.75,11.98 -0.48,17.81 z"
        id="path344"
        style="fill: url(#linear-gradient-80)"
      />
      <path
        class="cls-19"
        d="m 425.47985,498.69789 c 0.44,3.44 1.2,6.83 1.96,10.22 -6.17,-15.47 -6.42,-33.01 -1.87,-49.03 1.07,12.91 -1.74,25.96 -0.09,38.81 z"
        id="path346"
        style="fill: url(#linear-gradient-81)"
      />
      <path
        class="cls-67"
        d="m 466.04985,429.16789 c 0.28,-1.09 0.49,-2.2 0.53,-3.36 0.06,-1.65 0.16,-3.31 0.25,-4.96 2.81,14.67 2.59,29.91 -0.83,44.45 1.07,-17.47 0.77,-27.17 0.05,-36.13 z"
        id="path348"
        style="fill: url(#linear-gradient-82)"
      />
      <path
        class="cls-90"
        d="m 411.32985,319.86789 c -2.02,-1.08 -4.41,-2.65 -4.15,-4.92 21.38,8.43 38.22,27.56 43.87,49.84 3.35,13.21 2.93,27.05 2.49,40.67 -1.15,35.51 -2.29,71.02 -3.44,106.53 -0.15,4.6 -0.3,9.24 -1.44,13.7 -1.58,-30.91 -1.9,-61.88 -0.96,-92.82 0.21,-6.94 0.49,-13.89 1.28,-20.79 0.8,-6.99 2.13,-13.92 2.5,-20.95 1.49,-28.73 -14.8,-57.65 -40.15,-71.25 z"
        id="path350"
        style="fill: url(#linear-gradient-83)"
      />
      <path
        class="cls-38"
        d="m 424.84985,346.07789 c -2.43,-2.68 -6.79,-7.91 -9.69,-10.08 -2.9,-2.17 -9.44,-6 -9.49,-9.62 10.25,4.13 22.47,17.74 27.79,27.42 4.45,8.11 7.89,16.79 10.13,25.76 7.55,30.23 1.36,62.1 -6.61,92.23 -2.11,7.95 -4.35,15.97 -4.59,24.19 -3.5,-15.59 2.29,-31.52 5.87,-47.09 2.14,-9.3 3.5,-18.77 4.73,-28.24 0.64,-4.94 1.25,-9.89 1.27,-14.87 0.09,-18.08 -7.41,-35.23 -14.78,-51.74 -1.26,-2.82 -2.55,-5.69 -4.62,-7.97 z"
        id="path352"
        style="fill: url(#linear-gradient-84)"
      />
      <path
        class="cls-70"
        d="m 407.17985,348.38789 c -0.64,-0.67 -1.02,-2.14 -0.09,-2.19 12,8.88 20.49,22.4 23.27,37.07 0.92,4.86 1.24,9.81 1.55,14.75 1.5,23.53 3,47.07 4.5,70.6 0.34,5.37 0.68,10.76 0.47,16.14 -0.47,11.64 -3.55,23.23 -2.18,34.8 -5.84,-14.89 0.08,-31.6 -0.69,-47.57 -0.34,-7.05 -1.99,-13.98 -2.84,-20.99 -0.56,-4.66 -0.76,-9.35 -0.96,-14.04 -0.72,-16.89 -1.45,-33.78 -2.17,-50.67 -0.19,-4.42 -0.39,-8.9 -1.69,-13.12 -3.1,-10.08 -11.84,-17.17 -19.16,-24.77 z"
        id="path354"
        style="fill: url(#linear-gradient-85)"
      />
      <path
        class="cls-54"
        d="m 406.52985,352.71789 c 7.72,5.97 11.98,15.41 14.66,24.81 8.42,29.57 3.94,61.14 6.62,91.78 1.86,21.33 7.25,42.35 15.88,61.93 -1.85,-6.71 -5.26,-12.85 -8.12,-19.18 -8.66,-19.17 -9.56,-40.83 -11.14,-61.82 -1.58,-20.99 0.38,-30.28 -1.86,-51.22 -1.44,-13.47 -3.81,-26.31 -7.83,-32.39 -3.02,-4.57 -8.01,-8.43 -8.2,-13.92 z"
        id="path356"
        style="fill: url(#linear-gradient-86)"
      />
      <path
        class="cls-8"
        d="m 437.10985,560.87789 c 0.16,-4.34 0.94,-8.64 1.11,-12.99 0.28,-6.74 -1.79,-13.37 -2.27,-20.1 -0.14,-1.93 0.66,-9.27 1.87,-11.52 0.41,-0.76 1.08,1.78 1.08,1.78 -2.98,10.62 1.76,22.13 1.09,30.39 -0.97,12.04 -2.76,26.65 3.69,39.22 -5.16,-7.84 -6.92,-17.39 -6.58,-26.78 z"
        id="path358"
        style="fill: url(#linear-gradient-87)"
      />
      <path
        class="cls-102"
        d="m 445.77985,578.72789 c 0.07,-17.68 -3.27,-35.53 -1.75,-53.02 -1.12,-1.29 -1.95,-2.79 -2.53,-4.4 -0.08,0.47 -0.15,0.93 -0.17,1.37 -1.21,21.26 3.87,42.48 3.03,63.76 -0.37,9.41 -1.9,18.76 -2.02,28.18 -0.12,9.42 1.3,19.17 6.3,27.15 -7.87,-19.69 -2.94,-41.84 -2.86,-63.05 z"
        id="path360"
        style="fill: url(#linear-gradient-88)"
      />
      <path
        class="cls-86"
        d="m 460.91985,386.42789 c -1.78,-7.98 -4.91,-19.16 -8.4,-26.54 -4.78,-10.1 -11.58,-26.68 -22.53,-37.74 -5.21,-5.26 -15.83,-15.41 -25.1,-20.42 0.08,-1.24 0.07,-2.49 -0.12,-3.71 19.76,7.97 35.97,29.17 45.21,48.35 10.29,21.36 16.94,44.71 17.36,68.41 0.62,34.45 -11.09,67.27 -29.1,98.76 -4.01,7.01 -5.58,14.57 -5.83,22.64 -3.25,-7.34 -1.03,-16.02 2.83,-23.06 3.86,-7.04 18.71,-36.2 20.45,-44.48 1.34,-6.37 9.4,-35.38 8.54,-57.93 -0.36,-9.43 -1.8,-17.53 -3.3,-24.27 z"
        id="path362"
        style="fill: url(#linear-gradient-89)"
      />
      <path
        class="cls-139"
        d="m 448.06985,399.10789 c 1.83,-4.35 3.68,-8.76 4.3,-13.39 0.78,-5.86 -0.47,-11.79 -2.04,-17.52 -3.14,-11.4 -7.72,-22.62 -15.13,-32.24 -2.9,-3.77 -6.23,-7.28 -8.7,-11.29 -3.12,-5.07 -4.78,-10.77 -6.24,-16.43 -1.9,-7.37 -4.29,-13.14 -5.64,-20.6 -1.23,-6.8 -11.65,-19.02 -12.22,-19.95 -0.57,-0.93 -0.85,-4.44 0.31,-4.59 5.97,6.51 11.68,13.81 14.8,21.79 2.07,5.3 5.15,20.13 6.71,25.58 3.63,12.65 13.08,20.2 19.18,32.04 6.65,12.92 9.5,20.67 10.87,34.87 0.62,6.39 0.66,12.91 -0.98,19.15 -1.4,5.33 -5.49,10.57 -7.75,15.65 -3.5,7.88 -6.76,14.83 -6.64,24.11 -3.66,-5.42 -1.24,-12.41 1.26,-18.36 2.64,-6.27 5.28,-12.54 7.92,-18.82 z"
        id="path364"
        style="fill: url(#linear-gradient-90)"
      />
      <path
        class="cls-35"
        d="m 433.28985,286.72789 c -4.32,-3.45 -8.19,-7.43 -12.04,-11.39 -2.22,-2.27 -4.47,-4.6 -5.84,-7.47 -1.46,-3.05 -3.87,-7.1 -5.97,-9.76 -1.26,-1.6 -3.04,-2.74 -4.19,-4.42 -1.14,-1.68 -1.35,-4.34 0.34,-5.47 4.1,3.97 7.57,8.58 10.25,13.62 1.77,3.35 5.2,7.37 7.34,10.5 4.61,6.76 12,10.96 18.52,15.91 6.51,4.95 12.71,11.69 12.96,19.87 -2.19,-5.39 -5.15,-7.81 -8.43,-11.12 -3.88,-3.91 -8.62,-6.84 -12.93,-10.28 z"
        id="path366"
        style="fill: url(#linear-gradient-91)"
      />
      <path
        class="cls-10"
        d="m 404.68985,247.84789 c 8.53,4.82 16.07,11.37 22.04,19.15 1.86,2.42 3.63,5.18 3.59,8.23 0,0 -5.13,-5.34 -7.91,-8.41 -2.16,-2.39 -12.61,-9.76 -14.45,-11.74 -1.84,-1.98 -3.27,-4.52 -3.26,-7.22 z"
        id="path368"
        style="fill: url(#linear-gradient-92)"
      />
      <path
        class="cls-9"
        d="m 407.89985,273.46789 c 6.66,3.71 16.61,11.75 22.6,16.01 5.6,3.99 8.12,8.86 9.98,16.48 0.94,3.83 1.94,7.42 7.04,11.85 -2.13,-0.56 -6.12,-2.96 -6.91,-5.02 -0.79,-2.06 -2,-4.8 -2.51,-6.95 -1.08,-4.63 -3.53,-8.94 -6.95,-12.25 -2.85,-2.75 -20.72,-14.57 -23.17,-16.35 -0.03,-0.02 -0.05,-0.04 -0.08,-0.06 v -3.72 z"
        id="path370"
        style="fill: url(#linear-gradient-93)"
      />
      <path
        class="cls-126"
        d="m 422.57985,298.35789 c -2.14,-1.05 -6.36,-4.56 -8.11,-6.18 -5.28,-4.89 -7.5,-7.34 -7.5,-7.34 -0.21,-1.57 -0.65,-2.3 -1.56,-3.61 5.93,4.22 14.43,12.05 20.37,16.27 2.13,1.51 4.29,3.06 5.83,5.17 1.48,2.04 2.31,4.56 2.32,7.08 -1.81,-7.21 -8.93,-10.21 -11.34,-11.4 z"
        id="path372"
        style="fill: url(#linear-gradient-94)"
      />
      <path
        class="cls-53"
        d="m 515.51985,302.67789 c -1.53,-2.11 -3.7,-3.66 -5.83,-5.17 -3.4,-2.42 -7.64,-6.02 -11.76,-9.44 0.07,0.76 0.09,1.51 0.02,2.26 -0.04,0.47 -0.12,0.86 -0.17,1.3 0.21,0.19 0.38,0.36 0.6,0.56 1.75,1.62 5.97,5.13 8.11,6.18 2.42,1.19 9.53,4.19 11.34,11.39 0,-2.52 -0.83,-5.04 -2.32,-7.08 z"
        id="path374"
        style="fill: url(#linear-gradient-95)"
      />
      <path
        class="cls-106"
        d="m 412.33985,317.95789 c -1.5,-0.81 -3.14,-1.47 -4.33,-2.7 -1.18,-1.23 -1.75,-3.29 -0.72,-4.65 6.09,1.78 11.33,5.87 15.37,10.77 4.04,4.9 6.99,10.59 9.66,16.35 8.52,18.38 14.55,38.49 12.94,58.67 -0.65,8.16 -2.55,16.3 -1.79,24.45 -5.09,-16.69 0.47,-35.03 -3.58,-52 -1.21,-5.08 -3.26,-9.91 -5.29,-14.71 -1.84,-4.33 -3.67,-8.66 -5.51,-12.99 -3.8,-8.96 -8.18,-18.58 -16.75,-23.19 z"
        id="path376"
        style="fill: url(#linear-gradient-96)"
      />
      <path
        class="cls-46"
        d="m 415.75985,386.48789 c -0.31,-4.77 -0.79,-10.05 -2.2,-14.62 -1.87,-6.09 -3.79,-12.28 -7.34,-17.58 -1.25,2.59 -0.9,5.68 0.03,8.4 0.93,2.72 2.38,5.24 3.32,7.95 1.08,3.12 2.39,8.38 2.76,11.66 0.95,8.46 0.95,15.22 -1.33,23.41 4.1,-5.71 5.22,-12.21 4.77,-19.22 z"
        id="path378"
        style="fill: url(#linear-gradient-97)"
      />
      <path
        class="cls-81"
        d="m 420.44985,398.47789 c 1.2,-8.17 0.15,-16.54 -1.87,-24.54 -2.2,-8.71 -6.04,-17.74 -13.74,-22.36 0,0 3.4,6.31 6.25,11.11 7.65,12.87 9.95,33.53 4.14,47.33 3.22,-2.86 4.6,-7.27 5.23,-11.53 z"
        id="path380"
        style="fill: url(#linear-gradient-98)"
      />
      <path
        class="cls-117"
        d="m 426.67985,368.48789 c 0.56,3.97 0.23,8.44 -2.54,11.34 0.52,-3.74 1.04,-7.51 0.73,-11.27 -0.31,-3.76 -2.24,-7.04 -4.08,-10.33 -4.29,-7.68 -14.4,-16.33 -14.05,-17.02 0.35,-0.69 1.47,-0.99 1.9,-0.35 1.78,1.78 3.57,3.55 5.35,5.33 2.21,2.2 4.42,4.41 6.3,6.9 3.39,4.49 5.61,9.84 6.39,15.41 z"
        id="path382"
        style="fill: url(#linear-gradient-99)"
      />
      <path
        class="cls-109"
        d="m 429.10985,358.54789 c 5.54,9.16 8.64,20.63 4.79,30.62 0,0 -0.01,-9.2 -0.63,-13.86 -0.89,-6.77 -4.94,-12.77 -8.84,-18.68 -6.87,-10.42 -21.57,-23.73 -19.51,-25.53 1.21,0.74 2.42,1.47 3.63,2.21 0,0 15.03,16.09 20.57,25.25 z"
        id="path384"
        style="fill: url(#linear-gradient-100)"
      />
      <path
        class="cls-148"
        d="m 407.92985,323.21789 c 0.05,1.4 -0.11,-2.8 -0.16,-4.2 0.51,-0.48 1.34,-0.11 1.92,0.29 9.38,6.49 16.31,18.97 16.45,30.37 0,0 -3.47,-10.79 -4.4,-12.56 -4.79,-9.14 -13.84,-14.67 -13.81,-13.9 z"
        id="path386"
        style="fill: url(#linear-gradient-101)"
      />
      <path
        class="cls-89"
        d="m 416.43985,247.43789 c 3.53,2.36 7.42,4.21 10.66,6.95 3.24,2.74 5.87,6.67 5.65,10.91 -3.87,-4.76 -7.81,-9.59 -12.87,-13.06 -3.33,-2.29 -7.09,-3.94 -10.23,-6.49 -3.14,-2.55 -5.68,-6.36 -5.23,-10.38 3.16,4.76 7.28,8.89 12.03,12.07 z"
        id="path388"
        style="fill: url(#linear-gradient-102)"
      />
      <path
        class="cls-76"
        d="m 413.41985,237.70789 c -2.09,-1.35 -4.14,-2.76 -6.08,-4.32 -1.08,-0.86 -2.14,-1.8 -2.81,-3 -0.67,-1.21 -0.9,-2.66 -0.62,-4.02 3.2,4.99 8.51,8.2 13.81,10.86 5.3,2.66 10.87,5.02 15.3,8.96 4.43,3.95 7.57,9.97 6.27,15.75 -1.68,-5.82 -5.87,-10.62 -10.63,-14.36 -4.76,-3.74 -10.14,-6.6 -15.23,-9.87 z"
        id="path390"
        style="fill: url(#linear-gradient-103)"
      />
      <path
        class="cls-40"
        d="m 449.14985,255.03789 c -4.76,-8.47 -13.15,-14.17 -21.24,-19.55 -5.8,-3.87 -11.61,-7.73 -17.41,-11.6 -2.63,-1.75 -5.55,-4.01 -5.58,-7.16 13.28,7.32 26.76,14.79 37.47,25.53 3.5,3.51 6.86,7.83 6.76,12.79 z"
        id="path392"
        style="fill: url(#linear-gradient-104)"
      />
      <path
        class="cls-110"
        d="m 419.33985,214.58789 c 7.01,3.74 14.64,6.34 21.23,10.77 6.6,4.42 12.26,11.3 12.45,19.24 -8.65,-15.12 -24.89,-24.11 -40.8,-31.19 -2.19,-0.98 -4.45,-1.96 -6.19,-3.61 -1.75,-1.65 -2.91,-4.13 -2.34,-6.47 4.69,4.43 9.96,8.23 15.65,11.26 z"
        id="path394"
        style="fill: url(#linear-gradient-105)"
      />
      <path
        class="cls-49"
        d="m 413.00985,203.95789 c -1.94,-1.26 -3.71,-2.77 -5.48,-4.26 -2.17,-1.84 -4.53,-4.82 -2.92,-7.17 7.57,8 18.12,12.3 27.92,17.34 9.8,5.03 19.69,11.66 23.78,21.88 -9.84,-9.54 -21.32,-17.37 -33.78,-23.05 -3.23,-1.47 -6.54,-2.81 -9.51,-4.74 z"
        id="path396"
        style="fill: url(#linear-gradient-106)"
      />
      <path
        class="cls-78"
        d="m 457.17985,221.48789 c -13.24,-13.29 -32.02,-19.07 -48.54,-27.97 -0.95,-0.51 -1.92,-1.05 -2.66,-1.84 -1.34,-1.42 -1.77,-3.63 -1.07,-5.46 13.59,10.98 31.73,14.99 45.55,25.69 3.17,2.46 6.27,5.6 6.72,9.58 z"
        id="path398"
        style="fill: url(#linear-gradient-107)"
      />
      <path
        class="cls-37"
        d="m 403.37985,178.70789 c 0.56,-0.19 1.13,-0.38 1.69,-0.57 13.65,11.67 32.6,14.75 48.09,23.84 2.82,1.65 5.81,3.99 5.94,7.25 -14.98,-10.42 -33.28,-14.89 -49.2,-23.81 -2.8,-1.57 -5.76,-3.59 -6.53,-6.71 z"
        id="path400"
        style="fill: url(#linear-gradient-108)"
      />
      <path
        class="cls-12"
        d="m 414.28985,177.98789 c -4.23,-1.36 -9.06,-3.15 -10.5,-7.35 14.87,8.96 32.83,11.43 48.16,19.59 2.77,1.48 5.68,3.44 6.44,6.49 -14.1,-7.54 -28.88,-13.81 -44.09,-18.72 z"
        id="path402"
        style="fill: url(#linear-gradient-109)"
      />
      <path
        class="cls-58"
        d="m 411.53985,167.44789 c -1.56,-0.7 -3.12,-1.4 -4.62,-2.21 -0.68,-0.36 -1.36,-0.77 -1.82,-1.38 -0.58,-0.78 -0.72,-1.87 -0.36,-2.77 7.75,4.32 16.53,6.33 24.88,9.32 8.35,3 16.72,7.36 21.53,14.81 -13.2,-5.92 -26.41,-11.84 -39.61,-17.77 z"
        id="path404"
        style="fill: url(#linear-gradient-110)"
      />
      <path
        class="cls-50"
        d="m 404.44985,147.22789 c 3.9,3.55 8.37,6.53 13.2,8.8 12.61,5.92 27.01,6.81 40.92,8.55 13.91,1.74 28.45,4.78 38.82,13.86 -7.49,-2.9 -15.02,-5.81 -22.88,-7.56 -16.86,-3.76 -34.67,-2.07 -51.49,-6 -4.64,-1.08 -9.28,-2.65 -12.95,-5.59 -3.66,-2.94 -6.21,-7.49 -5.63,-12.04 z"
        id="path406"
        style="fill: url(#linear-gradient-111)"
      />
      <path
        class="cls-72"
        d="m 418.78985,109.53789 c 0.06,-1.04 0.12,-2.11 -0.2,-3.1 -0.31,-0.94 -0.94,-1.73 -1.55,-2.51 -2.1,-2.64 -4.27,-5.330004 -7.15,-7.090004 -1.4,-0.85 -2.96,-1.49 -4.1,-2.66 -1.14,-1.17 -1.7,-3.15 -0.69,-4.44 5.36,2.42 10.84,5.13 14.52,9.72 3.68,4.590004 5.03,11.570004 1.59,16.340004 -1.74,2.41 -4.46,3.96 -7.3,4.8 -2.84,0.84 -5.84,1.03 -8.8,1.15 0.85,-2.42 3.61,-3.52 6.09,-4.19 2.48,-0.67 5.25,-1.4 6.59,-3.59 0.8,-1.31 0.91,-2.91 1,-4.44 z"
        id="path408"
        style="fill: url(#linear-gradient-112)"
      />
      <path
        class="cls-93"
        d="m 407.52985,109.95789 c -1.55,-0.61 -2.39,-2.36 -3.22,-3.8 -0.83,-1.44 -1.04,-3.45 0.11,-4.65 7.68,4.57 11.23,13.95 11.94,22.86 0.71,8.91 -0.84,17.85 -0.67,26.79 0.22,11.7 0.71,44.19 0.13,48.82 -0.9,7.14 -0.5,14.38 -1.18,21.54 -0.68,7.16 -2.61,14.52 -7.4,19.88 -2.57,-2.23 -3.12,-6.43 -1.23,-9.24 0.51,-0.76 1.17,-1.42 1.62,-2.22 0.68,-1.21 0.75,-3.24 1.54,-2.1 4.03,5.85 4.32,-56.61 3.5,-66.59 -0.71,-8.6 5.1,-47.27 -5.16,-51.29 z"
        id="path410"
        style="fill: url(#linear-gradient-113)"
      />
      <path
        class="cls-74"
        d="m 471.08985,148.04789 c -11.4,1.79 -21.16,-1.97 -31.61,-5.55 -10.45,-3.58 -33.23,-16.46 -33.9,-17.94 -1.07,-2.38 1.97,0.26 0.35,-1.97 10.73,5.54 17.27,9.4 27.78,13.96 10.97,4.75 23.9,11.14 37.38,11.51 z"
        id="path412"
        style="fill: url(#linear-gradient-114)"
      />
      <path
        class="cls-136"
        d="m 404.55985,129.46789 c 11.93,6.29 23.93,12.61 37.26,17.4 13.33,4.79 28.2,8.02 43.25,7.66 -8.05,3.95 -19.22,2.41 -28.55,0.12 -13.03,-3.21 -25.4,-7.56 -37.33,-12.37 -7.2,-2.91 -15.15,-7.1 -14.63,-12.81 z"
        id="path414"
        style="fill: url(#linear-gradient-115)"
      />
      <path
        class="cls-122"
        d="m 419.18985,147.22789 c -1.54,-2.99 -4.55,-7.25 -6.56,-10.57 0.43,-1.12 0.75,-2.28 0.92,-3.47 9.14,11.68 14.07,26.32 15.88,41.07 1.89,15.46 0.62,31.14 -1.23,46.61 -0.7,5.92 -1.47,12.07 0.4,17.73 1.5,4.53 5.04,13.47 3.58,18.01 -0.05,-4.76 -3.98,-13 -6.18,-17.21 -4.19,-8.06 0.17,-26.46 0.67,-35.53 0.83,-14.86 1.16,-21.09 -1.48,-35.94 -0.94,-5.29 -3.55,-15.91 -6.01,-20.68 z"
        id="path416"
        style="fill: url(#linear-gradient-116)"
      />
      <path
        class="cls-64"
        d="m 462.86985,164.60789 c 3.34,1.88 6.74,3.72 9.65,6.21 3.41,2.92 6.02,6.66 8.31,10.53 5.06,8.58 8.67,18.01 10.62,27.78 3.42,17.16 12.05,52.41 20.21,70.49 -10.57,-16.62 -19.94,-49.37 -22.72,-64.98 -2.78,-15.61 -7.9,-31.88 -20.1,-42.01 -6.02,-5 -13.34,-8.13 -20.12,-12.03 -4.46,-2.56 -8.71,-5.48 -12.95,-8.39 -4.34,-2.98 -8.68,-5.95 -13.02,-8.92 -6.26,-4.3 -13.16,-9.67 -13.56,-17.25 16.41,14.78 34.44,27.74 53.68,38.58 z"
        id="path418"
        style="fill: url(#linear-gradient-117)"
      />
      <path
        class="cls-97"
        d="m 459.46985,175.27789 c 1.47,-1.19 2.4,-0.03 2.51,1.93 0.3,5.51 5.3,17.34 8.38,21.78 4.06,5.86 8.81,10.68 10.96,17.59 2.15,6.91 2.17,14.91 -1.5,21.05 1.17,-14.77 -0.94,-17.57 -1.94,-21.02 -0.5,-1.72 -1.4,-3.27 -2.34,-4.76 -3.58,-5.72 -7.72,-11.05 -10.96,-17 -3.24,-5.94 -5.59,-12.71 -5.09,-19.56 z"
        id="path420"
        style="fill: url(#linear-gradient-118)"
      />
      <path
        class="cls-2"
        d="m 503.90985,338.55789 c -3.31,-9.02 -6.98,-19.6 -9.77,-28.8 -7.29,-24.06 -8.86,-45.67 -8.5,-71.69 0.38,-27.2 -1.95,-44.26 -24.63,-60.91 -8.52,-6.25 -45.38,-27.94 -55.86,-29.26 -0.62,-1.6 0.09,-3.61 1.59,-4.46 16.82,10.21 62.67,28.45 72.66,45.41 9.47,16.09 9.12,28.36 9.33,47.03 0.14,11.62 -0.1,17.88 1.16,34.47 0.77,10.1 2.04,17.02 3.67,27.02 1.18,7.23 3.61,14.18 6.04,21.09 7.45,21.23 14.46,48.24 20.4,64.65 4.52,12.49 3.5,21.14 8.22,41.14 -7.02,-18.26 -3.76,-28.31 -9.62,-40.09 -3.04,-6.12 -11.63,-37.25 -14.7,-45.61 z"
        id="path422"
        style="fill: url(#linear-gradient-119)"
      />
      <path
        class="cls-45"
        d="m 534.20985,375.87789 c 0.27,0.11 0.54,0.22 0.81,0.32 3.67,1.4 7.14,3.32 10.28,5.68 3.19,2.4 5.89,5.62 9.5,7.43 -3.91,0.3 -8.24,-4.9 -12.14,-7.57 -3.98,-2.73 -8.73,-4.58 -13.71,-7.08 -2.26,-1.13 -6.76,-3.95 -9.21,-7.02 -1.41,-1.76 -1.16,-3.77 -1.9,-5.15 3.38,6.33 9.83,10.75 16.37,13.39 z"
        id="path424"
        style="fill: url(#linear-gradient-120)"
      />
      <path
        class="cls-85"
        d="m 532.57985,386.05789 c 1.59,2.09 5.01,6.42 6.37,8.67 4.09,6.77 5.32,12.96 6.98,22.63 -2.23,-8.07 -4.55,-16.32 -9.35,-23.13 -3.15,-4.46 -6.18,-8.95 -9.18,-13.52 -2.55,-3.88 -7.32,-10.18 -7.98,-14.81 3.71,7.51 8.19,13.64 13.16,20.15 z"
        id="path426"
        style="fill: url(#linear-gradient-121)"
      />
      <path
        class="cls-6"
        d="m 534.50985,407.77789 c 0.58,5.89 1.22,11.79 1.61,17.69 -2.99,-7.8 -1.99,-22.09 -5.03,-29.87 -0.81,-2.07 -1.93,-4.01 -2.94,-6 -2.72,-5.37 -3.74,-7.62 -4.72,-13.56 3.29,10.68 6.54,13.15 8.21,18.09 1.25,3.69 2.26,7.39 2.62,11.26 0.08,0.8 0.15,1.59 0.23,2.39 z"
        id="path428"
        style="fill: url(#linear-gradient-122)"
      />
      <path
        class="cls-119"
        d="m 523.93985,377.62789 c -0.69,8.99 0.52,11.19 3.18,17.38 1.5,3.48 1.5,11.72 0.75,19.56 0.17,-0.7 -0.06,-10.19 -0.75,-15.76 -0.46,-3.72 -3.23,-8.08 -3.94,-11.77 -0.63,-3.27 -0.71,-6.76 0.45,-9.85 0.1,0.14 0.2,0.29 0.3,0.43 z"
        id="path430"
        style="fill: url(#linear-gradient-123)"
      />
      <path
        class="cls-59"
        d="m 515.98985,373.92789 c 0.17,4.35 -0.32,6.78 0.37,19.92 0.35,6.6 1.34,14.36 1.48,20.73 -1.42,-9.68 -3.94,-25.61 -2.83,-40.88 0.32,0.11 0.65,0.16 0.99,0.23 z"
        id="path432"
        style="fill: url(#linear-gradient-124)"
      />
      <path
        class="cls-14"
        d="m 307.66985,316.02789 c -0.78,0.79 -2.28,1.73 -3.21,2.47 -2.02,1.59 -5.25,2.58 -8.1,3.74 -2.85,1.16 -5.56,2.75 -5.67,4.67 0.96,-1.27 2.25,-1.84 3.69,-2.61 1.7,-0.92 3.77,-1.61 5.65,-2.42 1.89,-0.81 3.58,-1.75 5.27,-2.68 0.97,-0.53 1.95,-1.08 2.55,-1.76 0.12,-0.13 0.3,-0.29 0.45,-0.44 v -1.51 c -0.2,0.18 -0.45,0.35 -0.64,0.54 z"
        id="path434"
        style="fill: url(#linear-gradient-125)"
      />
      <path
        class="cls-129"
        d="m 502.91985,316.02789 c 0.78,0.79 2.29,1.73 3.23,2.47 2.03,1.59 5.28,2.58 8.15,3.74 2.87,1.16 5.6,2.75 5.7,4.67 -0.96,-1.27 -2.26,-1.84 -3.71,-2.61 -1.71,-0.92 -3.8,-1.61 -5.69,-2.42 -1.9,-0.81 -3.6,-1.75 -5.3,-2.68 -0.98,-0.53 -1.97,-1.08 -2.57,-1.76 -0.12,-0.13 -0.31,-0.29 -0.45,-0.44 v -1.51 c 0.2,0.18 0.45,0.35 0.64,0.54 z"
        id="path436"
        style="fill: url(#linear-gradient-126)"
      />
      <path
        class="cls-71"
        d="m 406.23985,306.02789 c 14.39,5.79 28.77,12.21 40.79,22.02 12.02,9.81 21.57,23.48 23.44,38.88 -8.57,-21.11 -26,-38.47 -47.15,-46.95 -3.59,-1.44 -7.32,-2.66 -10.56,-4.77 -3.24,-2.12 -6.01,-5.34 -6.52,-9.18 z"
        id="path438"
        style="fill: url(#linear-gradient-127)"
      />
      <path
        class="cls-41"
        d="m 467.61985,709.00789 c -0.53,-0.69 -1.04,-1.66 -0.53,-2.37 2.58,3.38 5.71,6.35 9.23,8.74 1.38,0.94 2.84,1.8 3.96,3.04 -4.97,-1.91 -9.4,-5.2 -12.65,-9.41 z"
        id="path440"
        style="fill: url(#linear-gradient-128)"
      />
      <path
        class="cls-112"
        d="m 451.49985,688.49789 c 0.2,-1.6 0.39,-3.21 0.35,-4.82 -0.08,-2.75 -0.78,-5.82 0.86,-8.03 0.56,9.91 -0.55,19.91 -3.25,29.46 0.68,-5.54 1.36,-11.07 2.04,-16.61 z"
        id="path442"
        style="fill: url(#linear-gradient-129)"
      />
      <path
        class="cls-31"
        d="m 454.37985,711.64789 c 0.61,-2.11 0.94,-7.55 0.34,-11.76 0.98,0.85 1.16,2.76 1.21,4.06 0.16,4.44 -0.72,10.1 -1.5,14.48 -0.25,-1.12 -0.36,-5.66 -0.05,-6.77 z"
        id="path444"
        style="fill: url(#linear-gradient-130)"
      />
      <path
        class="cls-23"
        d="m 465.07985,699.11789 c 2.24,2.66 4.53,5.37 7.42,7.31 -2.59,-0.92 -4.62,-2.92 -6.56,-4.87 -0.24,-0.24 -0.49,-0.49 -0.63,-0.79 -0.24,-0.5 -0.19,-1.09 -0.22,-1.65 z"
        id="path446"
        style="fill: url(#linear-gradient-131)"
      />
      <path
        class="cls-123"
        d="m 460.02985,534.87789 c -0.4,-0.68 -0.81,-1.36 -1.05,-2.11 -0.32,-0.98 -0.34,-2.04 -0.35,-3.07 6.59,8.5 10.26,19.21 10.28,29.96 -1.4,-8.71 -4.43,-17.16 -8.88,-24.78 z"
        id="path448"
        style="fill: url(#linear-gradient-132)"
      />
      <path
        class="cls-15"
        d="m 312.05985,250.13789 c 1.92,9.47 2.37,19.24 1.32,28.84 -0.78,7.15 -2.69,20.51 -4.39,27.5 -6.94,28.63 -12.95,50.45 -26.44,80.88 9.28,-18.11 17.45,-39.93 23.76,-59.27 4.12,-12.64 6.57,-26.1 8.17,-39.3 1.6,-13.19 2.28,-26.22 -2.43,-38.65 z"
        id="path450"
        style="fill: url(#linear-gradient-133)"
      />
      <path
        class="cls-104"
        d="m 508.27985,289.59789 c 3.97,21.01 5.51,37.31 13.07,61.19 3.02,9.53 6.9,20.85 16.68,22.92 -4.03,0.07 -8.05,-1.92 -10.45,-5.16 -0.76,2.84 3.96,10.27 4.21,13.21 -4.16,-6.85 -5.88,-12.3 -8.68,-19.72 -5.16,-13.68 -9.71,-29.53 -12.43,-42.14 -2.04,-9.45 -2.89,-19.15 -5.3,-28.51 -1.98,-7.66 -3.42,-13.66 -5.5,-21.3 -4.49,-16.42 -1.7,-32.86 -3.43,-49.79 -1.74,-16.93 -9.9,-36.54 -20.25,-50.05 -8.36,-10.91 -20.38,-18.36 -32.36,-25.1 -2.6,-1.46 -8.23,-4.77 -10.47,-6.75 -4.69,-4.15 -21.71,-18.27 -19.49,-20.26 11.26,13.3 54.5,37.3 66.66,52.56 12.25,15.36 18.24,35.09 19.2,54.71 0.69,14.11 -1.06,28.44 1.81,42.28 1.55,7.49 5.3,14.41 6.72,21.93 z"
        id="path452"
        style="fill: url(#linear-gradient-134)"
      />
      <path
        class="cls-60"
        d="m 498.70985,250.13789 c -1.92,9.47 -2.37,19.24 -1.32,28.84 0.78,7.15 2.69,20.51 4.39,27.5 6.94,28.63 12.95,50.45 26.44,80.88 -9.28,-18.11 -17.45,-39.93 -23.76,-59.27 -4.12,-12.64 -6.57,-26.1 -8.17,-39.3 -1.6,-13.19 -2.28,-26.22 2.43,-38.65 z"
        id="path454"
        style="fill: url(#linear-gradient-135)"
      />
      <path
        class="cls-39"
        d="m 302.48985,289.59789 c -3.97,21.01 -5.51,37.31 -13.07,61.19 -3.02,9.53 -6.9,20.85 -16.68,22.92 4.03,0.07 8.05,-1.92 10.45,-5.16 0.76,2.84 -3.97,10.27 -4.21,13.21 4.16,-6.85 5.88,-12.3 8.68,-19.72 5.16,-13.68 9.71,-29.53 12.43,-42.14 2.04,-9.45 2.89,-19.15 5.3,-28.51 1.98,-7.66 3.42,-13.66 5.5,-21.3 4.49,-16.42 1.7,-32.86 3.43,-49.79 1.74,-16.93 9.9,-36.54 20.25,-50.05 8.36,-10.91 20.38,-18.36 32.36,-25.1 2.6,-1.46 8.23,-4.77 10.47,-6.75 4.69,-4.15 21.71,-18.27 19.49,-20.26 -11.26,13.3 -54.5,37.3 -66.66,52.56 -12.25,15.36 -18.23,35.09 -19.2,54.71 -0.69,14.11 1.06,28.44 -1.81,42.28 -1.55,7.49 -5.3,14.41 -6.72,21.93 z"
        id="path456"
        style="fill: url(#linear-gradient-136)"
      />
      <g id="g528" transform="translate(248.68985,28.077886)">
        <g id="g518">
          <g id="g474">
            <path
              class="cls-113"
              d="M 178.34,18.27 C 175.54,11.79 164.85,8.61 162.78,6.65 160.71,4.69 157.32,5.69 157.32,5.69 h -1.25 c 0,0 -3.4,-1 -5.46,0.96 -2.06,1.96 -12.76,5.14 -15.56,11.62 -2.8,6.48 -9.01,13.75 -7.54,18.31 1.46,4.56 4.71,17.37 5.13,19.15 0.41,1.78 11.17,6.21 14.33,4.37 2.04,-1.18 5.98,-1.2 8.53,-1.06 v 0.2 c 0,0 0.46,-0.06 1.2,-0.12 0.74,0.06 1.21,0.12 1.21,0.12 v -0.2 c 2.55,-0.14 6.49,-0.13 8.53,1.06 3.16,1.83 13.92,-2.59 14.33,-4.37 0.41,-1.78 3.66,-14.59 5.13,-19.15 1.47,-4.56 -4.75,-11.83 -7.54,-18.31 z"
              id="path458"
            />
            <g id="g472">
              <path
                class="cls-63"
                d="m 130.42,35.85 c 4.21,3.54 9.11,6.23 14.33,7.89 2.52,0.8 5.43,1.3 7.65,-0.13 2.24,-1.44 2.99,-4.35 3.35,-7 1.2,-8.97 -0.03,-18.07 -1.27,-27.04 -0.14,-1 -0.3,-2.06 -0.95,-2.84 -1.17,-1.4 -3.43,-1.25 -5.03,-0.37 -1.6,0.87 -2.85,2.29 -4.41,3.24 -2.92,1.77 -6.81,1.84 -9.21,4.27 -2.32,2.36 -2.41,6.09 -3.78,9.12 -1.43,3.19 -4.42,6.3 -3.29,9.61 0.46,1.33 1.52,2.35 2.6,3.25 z"
                id="path460"
                style="fill: url(#radialGradient1354)"
              />
              <path
                class="cls-95"
                d="m 128.48,44.16 c 0.07,1.15 -0.11,2.32 0.07,3.46 0.32,2.02 1.76,3.75 3.52,4.76 1.76,1.02 3.83,1.4 5.86,1.5 3.01,0.15 6.1,-0.31 8.8,-1.64 2.71,-1.33 5.02,-3.59 6.12,-6.42 0.05,-0.13 0.1,-0.29 0.04,-0.42 -0.11,-0.24 -0.46,-0.2 -0.71,-0.12 -3.25,0.98 -6.83,0.78 -9.96,-0.55 -1.65,-0.7 -3.16,-1.71 -4.66,-2.7 -3.18,-2.11 -6.36,-4.23 -9.54,-6.34 -1.39,2.52 0.27,5.58 0.44,8.46 z"
                id="path462"
                style="fill: url(#radial-gradient-2)"
              />
              <path
                class="cls-101"
                d="m 153.04,48.9 c 0.37,-0.78 0.65,-1.79 1.48,-2.02 0.68,-0.19 1.41,0.31 1.71,0.96 0.31,0.64 0.3,1.39 0.28,2.1 -0.03,1.5 -0.06,3.01 -0.09,4.51 -0.05,2.75 -0.21,5.77 -2.07,7.79 -1.92,2.09 -5.06,2.42 -7.88,2.36 -3.14,-0.07 -6.37,-0.51 -9.07,-2.11 -2.71,-1.6 -4.79,-4.57 -4.58,-7.72 1.46,-0.34 2.95,0.19 4.44,0.4 3.47,0.48 6.9,-0.85 10.15,-2.15 2.21,-0.89 4.62,-1.95 5.64,-4.12 z"
                id="path464"
                style="fill: url(#radial-gradient-3)"
              />
              <path
                class="cls-34"
                d="m 182.97,35.85 c -4.21,3.54 -9.11,6.23 -14.33,7.89 -2.52,0.8 -5.43,1.3 -7.65,-0.13 -2.24,-1.44 -2.99,-4.35 -3.35,-7 -1.2,-8.97 0.03,-18.07 1.27,-27.04 0.14,-1 0.3,-2.06 0.95,-2.84 1.17,-1.4 3.43,-1.25 5.03,-0.37 1.6,0.88 2.85,2.29 4.41,3.24 2.92,1.77 6.81,1.84 9.21,4.27 2.32,2.36 2.41,6.09 3.78,9.12 1.43,3.19 4.42,6.3 3.29,9.61 -0.46,1.33 -1.52,2.35 -2.6,3.25 z"
                id="path466"
                style="fill: url(#radial-gradient-4)"
              />
              <path
                class="cls-32"
                d="m 184.91,44.16 c -0.07,1.15 0.11,2.32 -0.07,3.46 -0.32,2.02 -1.76,3.75 -3.52,4.76 -1.76,1.02 -3.83,1.4 -5.86,1.5 -3.01,0.15 -6.1,-0.31 -8.8,-1.64 -2.71,-1.33 -5.02,-3.59 -6.12,-6.42 -0.05,-0.13 -0.1,-0.29 -0.04,-0.42 0.11,-0.24 0.46,-0.2 0.71,-0.12 3.25,0.98 6.83,0.78 9.96,-0.55 1.65,-0.7 3.16,-1.71 4.66,-2.7 3.18,-2.11 6.36,-4.23 9.54,-6.34 1.39,2.52 -0.27,5.58 -0.44,8.46 z"
                id="path468"
                style="fill: url(#radial-gradient-5)"
              />
              <path
                class="cls-56"
                d="m 160.35,48.9 c -0.37,-0.78 -0.65,-1.79 -1.48,-2.02 -0.68,-0.19 -1.41,0.31 -1.71,0.96 -0.31,0.64 -0.3,1.39 -0.28,2.1 0.03,1.5 0.06,3.01 0.09,4.51 0.05,2.75 0.21,5.77 2.07,7.79 1.92,2.09 5.06,2.42 7.88,2.36 3.14,-0.07 6.37,-0.51 9.07,-2.11 2.71,-1.6 4.79,-4.57 4.58,-7.72 -1.46,-0.34 -2.95,0.19 -4.44,0.4 -3.47,0.48 -6.9,-0.85 -10.15,-2.15 -2.21,-0.89 -4.62,-1.95 -5.64,-4.12 z"
                id="path470"
                style="fill: url(#radial-gradient-6)"
              />
            </g>
          </g>
          <g id="g516">
            <g id="g494">
              <path
                class="cls-137"
                d="m 144.92,15.12 h -0.11 c -1.5,-0.03 -2.97,-0.78 -3.93,-2 -0.16,-0.2 -0.14,-0.5 0.05,-0.67 0.19,-0.17 0.47,-0.15 0.63,0.06 0.81,1.01 2.03,1.63 3.27,1.66 0.58,0.04 1.2,-0.09 1.96,-0.32 0.55,-0.17 0.99,-0.35 1.37,-0.56 1.47,-0.83 2.52,-2.5 2.68,-4.26 0.02,-0.25 0.22,-0.43 0.44,-0.43 0.01,0 0.03,0 0.04,0 0.25,0.02 0.43,0.26 0.4,0.52 -0.18,2.07 -1.42,4.04 -3.15,5.01 -0.44,0.25 -0.93,0.45 -1.54,0.64 -0.8,0.25 -1.48,0.36 -2.12,0.36 z"
                id="path476"
              />
              <path
                class="cls-137"
                d="m 155.84,46.97 c 0,0 -0.09,0 -0.13,-0.02 -1.65,-0.53 -3.15,-1.51 -4.34,-2.83 -0.43,-0.48 -0.81,-1 -1.19,-1.5 -0.59,-0.8 -1.15,-1.55 -1.86,-2.14 -0.52,-0.44 -1.12,-0.77 -1.75,-1.13 -1,-0.56 -2.03,-1.15 -2.75,-2.15 -1.17,-1.64 -1.27,-4.01 -0.29,-7.02 0.12,-0.39 0.26,-0.78 0.4,-1.16 0.6,-1.72 1.22,-3.49 1.01,-5.24 -0.06,-0.5 -0.18,-0.99 -0.31,-1.52 -0.26,-1.08 -0.53,-2.2 -0.23,-3.33 0.17,-0.63 0.5,-1.2 0.81,-1.76 0.5,-0.87 0.93,-1.63 0.65,-2.36 -0.09,-0.24 0.01,-0.52 0.24,-0.62 0.24,-0.1 0.49,0.02 0.58,0.26 0.45,1.17 -0.17,2.25 -0.71,3.21 -0.29,0.5 -0.58,1.02 -0.72,1.53 -0.24,0.89 0,1.83 0.23,2.83 0.13,0.53 0.26,1.08 0.33,1.64 0.23,1.98 -0.42,3.87 -1.06,5.69 -0.13,0.38 -0.26,0.76 -0.39,1.14 -0.88,2.7 -0.82,4.76 0.16,6.13 0.6,0.84 1.51,1.35 2.46,1.89 0.64,0.36 1.29,0.74 1.88,1.22 0.79,0.66 1.41,1.5 2.01,2.3 0.36,0.49 0.73,0.99 1.13,1.43 1.08,1.21 2.45,2.1 3.95,2.58 0.24,0.07 0.37,0.34 0.3,0.59 -0.06,0.21 -0.24,0.34 -0.43,0.34 z"
                id="path478"
              />
              <path
                class="cls-137"
                d="m 143.11,31.94 c -0.1,0 -0.21,-0.04 -0.28,-0.11 -0.11,0 -0.22,-0.02 -0.29,-0.04 -0.36,-0.08 -0.72,-0.16 -1.09,-0.25 l -0.22,-0.05 c -0.78,-0.19 -1.39,-0.33 -2.12,-0.97 -1.68,-1.49 -1.8,-3.7 -0.32,-5.79 0.13,-0.19 0.29,-0.39 0.46,-0.6 0.95,-1.21 1.58,-2.15 0.94,-3.09 -0.3,-0.44 -0.91,-0.67 -1.56,-0.91 -0.78,-0.29 -1.67,-0.62 -2.2,-1.44 -0.14,-0.22 -0.09,-0.51 0.12,-0.66 0.21,-0.14 0.49,-0.09 0.62,0.12 0.36,0.56 1.04,0.82 1.76,1.08 0.75,0.28 1.52,0.56 1.98,1.25 1.1,1.61 -0.15,3.2 -0.97,4.26 -0.15,0.2 -0.3,0.38 -0.42,0.56 -0.57,0.8 -1.69,2.84 0.17,4.49 0.56,0.49 1.01,0.6 1.74,0.77 l 0.18,0.04 c 0.41,0.1 0.76,0.19 1.11,0.26 0.08,0.02 0.18,0.02 0.27,0.03 0.26,0.02 0.65,0.06 0.69,0.48 0.01,0.16 -0.03,0.44 -0.44,0.55 -0.04,0 -0.08,0.02 -0.11,0.02 z"
                id="path480"
              />
              <path
                class="cls-137"
                d="m 147.82,39.86 c -0.13,0 -0.25,-0.06 -0.34,-0.17 -0.16,-0.2 -0.13,-0.5 0.06,-0.67 l 0.45,-0.39 c 1.01,-0.88 2.06,-1.79 2.25,-3.02 0.14,-0.91 -0.22,-1.81 -0.59,-2.76 -0.22,-0.56 -0.45,-1.15 -0.59,-1.75 -0.41,-1.83 0.12,-3.88 1.34,-5.22 0.2,-0.22 0.42,-0.43 0.65,-0.65 0.53,-0.5 1.03,-0.97 1.19,-1.58 0.13,-0.53 -0.05,-1.16 -0.45,-1.52 -0.4,-0.36 -1.01,-0.45 -1.49,-0.23 -0.22,0.11 -0.49,0 -0.59,-0.24 -0.1,-0.24 0,-0.52 0.23,-0.62 0.78,-0.38 1.76,-0.23 2.43,0.37 0.66,0.6 0.95,1.6 0.73,2.49 -0.22,0.89 -0.85,1.48 -1.46,2.05 -0.21,0.19 -0.41,0.39 -0.6,0.59 -1.02,1.12 -1.46,2.82 -1.12,4.34 0.12,0.53 0.33,1.05 0.54,1.61 0.41,1.03 0.83,2.1 0.65,3.28 -0.24,1.59 -1.47,2.66 -2.56,3.61 l -0.44,0.39 c -0.08,0.07 -0.19,0.11 -0.29,0.11 z"
                id="path482"
              />
              <path
                class="cls-137"
                d="m 153.07,50.83 c -0.36,0 -0.68,-0.04 -0.93,-0.09 -1.82,-0.34 -3.37,-1.43 -4.86,-2.49 -0.59,-0.42 -1.21,-0.86 -1.82,-1.23 -1.6,-0.97 -3.38,-1.63 -5.11,-2.27 -1.52,-0.56 -3.09,-1.15 -4.56,-1.94 -2.06,-1.11 -3.27,-2.49 -3.61,-4.09 -0.24,-1.13 -0.01,-2.25 0.2,-3.33 0.08,-0.42 0.17,-0.83 0.22,-1.25 0.17,-1.3 -0.13,-2.88 -1.2,-3.29 -0.23,-0.09 -0.35,-0.36 -0.27,-0.61 0.08,-0.24 0.35,-0.37 0.57,-0.29 1.54,0.59 2.01,2.59 1.78,4.31 -0.06,0.44 -0.15,0.88 -0.23,1.32 -0.21,1.03 -0.4,1.99 -0.2,2.92 0.28,1.31 1.34,2.47 3.15,3.45 1.41,0.77 2.96,1.34 4.45,1.89 1.77,0.65 3.6,1.33 5.26,2.35 0.64,0.39 1.27,0.83 1.87,1.26 1.48,1.05 2.88,2.04 4.51,2.35 1.03,0.19 1.94,0 2.52,-0.51 0.33,-0.29 0.55,-0.77 0.58,-1.25 0.01,-0.26 -0.02,-0.63 -0.28,-0.92 -0.17,-0.19 -0.16,-0.49 0.02,-0.67 0.17,-0.18 0.46,-0.17 0.63,0.02 0.37,0.42 0.56,0.99 0.52,1.62 -0.04,0.74 -0.38,1.46 -0.9,1.92 -0.71,0.63 -1.59,0.8 -2.31,0.8 z"
                id="path484"
              />
              <path
                class="cls-137"
                d="m 138.86,47.76 c -1.58,0 -3.17,-0.88 -4,-2.32 l -0.1,-0.17 c -0.1,-0.18 -0.19,-0.34 -0.3,-0.46 -0.37,-0.37 -1.03,-0.27 -1.73,-0.17 -0.14,0.02 -0.29,0.05 -0.43,0.06 -1.11,0.15 -2.27,-0.08 -3.26,-0.61 -0.22,-0.12 -0.3,-0.41 -0.19,-0.64 0.12,-0.23 0.39,-0.32 0.6,-0.21 0.83,0.45 1.82,0.63 2.75,0.52 l 0.4,-0.06 c 0.81,-0.12 1.79,-0.27 2.48,0.42 0.2,0.21 0.33,0.44 0.45,0.66 l 0.09,0.16 c 0.83,1.44 2.59,2.18 4.13,1.74 0.41,-0.12 0.81,-0.31 1.22,-0.52 0.3,-0.15 0.6,-0.3 0.92,-0.42 0.61,-0.24 1.47,-0.45 2.26,-0.17 0.65,-1.31 0.4,-3.12 -0.62,-4.13 -0.32,-0.32 -0.71,-0.57 -1.12,-0.83 -0.49,-0.31 -0.99,-0.64 -1.41,-1.11 -0.9,-0.99 -1.24,-2.49 -0.86,-3.81 0.07,-0.25 0.32,-0.4 0.56,-0.32 0.24,0.07 0.37,0.34 0.3,0.59 -0.28,0.98 -0.01,2.14 0.65,2.88 0.34,0.37 0.78,0.66 1.23,0.95 0.43,0.28 0.87,0.56 1.26,0.94 1.45,1.43 1.7,3.98 0.56,5.69 l -0.23,0.35 -0.35,-0.2 c -0.63,-0.37 -1.47,-0.13 -1.91,0.05 -0.29,0.11 -0.57,0.25 -0.85,0.39 -0.43,0.21 -0.88,0.44 -1.37,0.57 -0.37,0.11 -0.74,0.16 -1.12,0.16 z"
                id="path486"
              />
              <path
                class="cls-137"
                d="m 140.84,54.46 c -0.47,0 -0.97,-0.11 -1.51,-0.31 -1.51,-0.57 -2.83,-1.67 -3.72,-3.08 -0.14,-0.22 -0.08,-0.51 0.12,-0.66 0.21,-0.15 0.49,-0.09 0.62,0.13 0.79,1.25 1.96,2.21 3.29,2.72 0.57,0.22 1.38,0.41 2.01,0.07 0.27,-0.15 0.51,-0.39 0.76,-0.64 0.25,-0.25 0.51,-0.52 0.84,-0.72 0.81,-0.51 1.75,-0.49 2.64,-0.42 0.82,0.06 1.58,0.11 2.19,-0.18 0.33,-0.16 0.62,-0.48 0.74,-0.82 0.06,-0.16 0.1,-0.4 0,-0.64 -0.1,-0.24 0,-0.52 0.22,-0.63 0.22,-0.12 0.49,0 0.59,0.23 0.18,0.42 0.19,0.9 0.03,1.37 -0.21,0.59 -0.66,1.09 -1.21,1.36 -0.82,0.4 -1.73,0.33 -2.54,0.27 -0.83,-0.05 -1.62,-0.09 -2.21,0.28 -0.24,0.15 -0.45,0.36 -0.68,0.59 -0.29,0.29 -0.59,0.59 -0.98,0.8 -0.35,0.19 -0.76,0.29 -1.21,0.29 z"
                id="path488"
              />
              <path
                class="cls-137"
                d="m 143.34,59.98 c -0.77,0 -1.53,-0.18 -2.2,-0.36 -0.24,-0.06 -0.39,-0.32 -0.33,-0.57 0.06,-0.25 0.31,-0.4 0.54,-0.35 0.85,0.23 1.83,0.45 2.74,0.25 0.73,-0.16 1.58,-0.73 1.74,-1.61 0.02,-0.1 0.03,-0.21 0.04,-0.32 0.02,-0.22 0.04,-0.47 0.13,-0.72 0.21,-0.62 0.76,-1.1 1.51,-1.3 0.39,-0.11 0.77,-0.14 1.14,-0.16 0.17,-0.01 0.34,-0.02 0.5,-0.05 2.17,-0.27 4.14,-2.13 4.67,-4.38 -0.13,-0.17 -0.13,-0.52 0,-0.7 0.14,-0.21 0.38,-0.29 0.61,-0.18 0.22,0.1 0.42,0.37 0.33,0.82 -0.52,2.79 -2.83,5.05 -5.49,5.38 -0.18,0.02 -0.36,0.03 -0.54,0.05 -0.35,0.02 -0.67,0.05 -0.98,0.13 -0.45,0.13 -0.79,0.39 -0.89,0.71 -0.05,0.14 -0.07,0.31 -0.08,0.48 -0.01,0.14 -0.03,0.27 -0.05,0.4 -0.24,1.32 -1.4,2.13 -2.44,2.36 -0.31,0.07 -0.63,0.1 -0.94,0.1 z"
                id="path490"
              />
              <path
                class="cls-137"
                d="m 151.81,63.14 c -0.07,0 -0.14,0 -0.21,-0.02 -0.24,-0.03 -0.42,-0.27 -0.38,-0.53 0.03,-0.26 0.27,-0.44 0.5,-0.4 0.15,0.01 0.31,-0.02 0.44,-0.1 0.45,-0.3 0.47,-1.1 0.44,-1.56 -0.06,-1.03 -0.31,-2.04 -0.73,-2.98 l -0.08,-0.19 c -0.12,-0.26 -0.24,-0.53 -0.32,-0.84 -0.39,-1.52 0.53,-2.94 1.49,-4.14 0.16,-0.2 0.44,-0.23 0.63,-0.05 0.19,0.17 0.21,0.47 0.05,0.67 -0.8,1 -1.58,2.17 -1.31,3.27 0.06,0.23 0.16,0.45 0.26,0.67 l 0.09,0.2 c 0.47,1.05 0.74,2.17 0.81,3.32 0.08,1.16 -0.22,2 -0.85,2.42 -0.25,0.17 -0.54,0.25 -0.83,0.25 z"
                id="path492"
              />
            </g>
            <g id="g514">
              <path
                class="cls-137"
                d="m 168.48,15.12 h 0.11 c 1.5,-0.03 2.97,-0.78 3.93,-2 0.16,-0.2 0.14,-0.5 -0.05,-0.67 -0.19,-0.17 -0.47,-0.15 -0.63,0.06 -0.81,1.01 -2.03,1.63 -3.27,1.66 -0.58,0.04 -1.2,-0.09 -1.96,-0.32 -0.55,-0.17 -0.99,-0.35 -1.37,-0.56 -1.47,-0.83 -2.52,-2.5 -2.68,-4.26 -0.02,-0.25 -0.22,-0.43 -0.44,-0.43 -0.01,0 -0.03,0 -0.04,0 -0.25,0.02 -0.43,0.26 -0.4,0.52 0.18,2.07 1.42,4.04 3.15,5.01 0.44,0.25 0.93,0.45 1.54,0.64 0.8,0.25 1.48,0.36 2.12,0.36 z"
                id="path496"
              />
              <path
                class="cls-137"
                d="m 157.55,46.97 c 0,0 0.09,0 0.13,-0.02 1.65,-0.53 3.15,-1.51 4.34,-2.83 0.43,-0.48 0.81,-1 1.19,-1.5 0.59,-0.8 1.15,-1.55 1.86,-2.14 0.52,-0.44 1.12,-0.77 1.75,-1.13 1,-0.56 2.03,-1.15 2.75,-2.15 1.17,-1.64 1.27,-4.01 0.29,-7.02 -0.12,-0.39 -0.26,-0.78 -0.4,-1.16 -0.6,-1.72 -1.22,-3.49 -1.01,-5.24 0.06,-0.5 0.18,-0.99 0.31,-1.52 0.26,-1.08 0.53,-2.2 0.23,-3.33 -0.17,-0.63 -0.5,-1.2 -0.81,-1.76 -0.5,-0.87 -0.93,-1.63 -0.65,-2.36 0.09,-0.24 -0.01,-0.52 -0.24,-0.62 -0.24,-0.1 -0.49,0.02 -0.58,0.26 -0.45,1.17 0.17,2.25 0.71,3.21 0.29,0.5 0.58,1.02 0.72,1.53 0.24,0.89 0,1.83 -0.23,2.83 -0.13,0.53 -0.26,1.08 -0.33,1.64 -0.23,1.98 0.42,3.87 1.06,5.69 0.13,0.38 0.26,0.76 0.39,1.14 0.88,2.7 0.82,4.76 -0.16,6.13 -0.6,0.84 -1.51,1.35 -2.46,1.89 -0.64,0.36 -1.29,0.74 -1.88,1.22 -0.79,0.66 -1.41,1.5 -2.01,2.3 -0.36,0.49 -0.73,0.99 -1.13,1.43 -1.08,1.21 -2.45,2.1 -3.95,2.58 -0.24,0.07 -0.37,0.34 -0.3,0.59 0.06,0.21 0.24,0.34 0.43,0.34 z"
                id="path498"
              />
              <path
                class="cls-137"
                d="m 170.28,31.94 c 0.1,0 0.21,-0.04 0.28,-0.11 0.11,0 0.22,-0.02 0.29,-0.04 0.36,-0.08 0.72,-0.16 1.09,-0.25 l 0.22,-0.05 c 0.78,-0.19 1.39,-0.33 2.12,-0.97 1.68,-1.49 1.8,-3.7 0.32,-5.79 -0.13,-0.19 -0.29,-0.39 -0.46,-0.6 -0.95,-1.21 -1.58,-2.15 -0.94,-3.09 0.3,-0.44 0.91,-0.67 1.56,-0.91 0.79,-0.29 1.67,-0.62 2.2,-1.44 0.14,-0.22 0.09,-0.51 -0.12,-0.66 -0.21,-0.14 -0.49,-0.09 -0.62,0.12 -0.36,0.56 -1.04,0.82 -1.76,1.08 -0.75,0.28 -1.52,0.56 -1.98,1.25 -1.1,1.61 0.15,3.2 0.97,4.26 0.15,0.2 0.3,0.38 0.42,0.56 0.57,0.8 1.69,2.84 -0.17,4.49 -0.56,0.49 -1.01,0.6 -1.74,0.77 l -0.18,0.04 c -0.41,0.1 -0.76,0.19 -1.11,0.26 -0.08,0.02 -0.18,0.02 -0.27,0.03 -0.26,0.02 -0.65,0.06 -0.69,0.48 -0.01,0.16 0.03,0.44 0.44,0.55 0.04,0 0.08,0.02 0.11,0.02 z"
                id="path500"
              />
              <path
                class="cls-137"
                d="m 165.57,39.86 c 0.13,0 0.25,-0.06 0.34,-0.17 0.16,-0.2 0.13,-0.5 -0.06,-0.67 l -0.45,-0.39 c -1.01,-0.88 -2.06,-1.79 -2.25,-3.02 -0.14,-0.91 0.22,-1.81 0.59,-2.76 0.22,-0.56 0.45,-1.15 0.59,-1.75 0.41,-1.83 -0.12,-3.88 -1.34,-5.22 -0.2,-0.22 -0.42,-0.43 -0.65,-0.65 -0.53,-0.5 -1.03,-0.97 -1.19,-1.58 -0.13,-0.53 0.05,-1.16 0.45,-1.52 0.4,-0.36 1.01,-0.45 1.49,-0.23 0.22,0.11 0.49,0 0.59,-0.24 0.1,-0.24 0,-0.52 -0.23,-0.62 -0.78,-0.38 -1.76,-0.23 -2.43,0.37 -0.66,0.6 -0.95,1.6 -0.73,2.49 0.22,0.89 0.85,1.48 1.46,2.05 0.21,0.19 0.41,0.39 0.6,0.59 1.02,1.12 1.46,2.82 1.12,4.34 -0.12,0.53 -0.33,1.05 -0.54,1.61 -0.41,1.03 -0.83,2.1 -0.65,3.28 0.24,1.59 1.47,2.66 2.56,3.61 l 0.44,0.39 c 0.08,0.07 0.19,0.11 0.29,0.11 z"
                id="path502"
              />
              <path
                class="cls-137"
                d="m 160.32,50.83 c 0.36,0 0.68,-0.04 0.93,-0.09 1.82,-0.34 3.37,-1.43 4.86,-2.49 0.59,-0.42 1.21,-0.86 1.82,-1.23 1.6,-0.97 3.38,-1.63 5.11,-2.27 1.52,-0.56 3.09,-1.15 4.56,-1.94 2.06,-1.11 3.27,-2.49 3.61,-4.09 0.24,-1.13 0.01,-2.25 -0.2,-3.33 -0.08,-0.42 -0.17,-0.83 -0.22,-1.25 -0.17,-1.3 0.13,-2.88 1.2,-3.29 0.23,-0.09 0.35,-0.36 0.27,-0.61 -0.08,-0.24 -0.35,-0.37 -0.57,-0.29 -1.54,0.59 -2.01,2.59 -1.78,4.31 0.06,0.44 0.15,0.88 0.23,1.32 0.21,1.03 0.4,1.99 0.2,2.92 -0.28,1.31 -1.34,2.47 -3.15,3.45 -1.41,0.77 -2.96,1.34 -4.45,1.89 -1.77,0.65 -3.6,1.33 -5.26,2.35 -0.64,0.39 -1.27,0.83 -1.87,1.26 -1.48,1.05 -2.88,2.04 -4.51,2.35 -1.03,0.19 -1.94,0 -2.52,-0.51 -0.33,-0.29 -0.55,-0.77 -0.58,-1.25 -0.01,-0.26 0.02,-0.63 0.28,-0.92 0.17,-0.19 0.16,-0.49 -0.02,-0.67 -0.17,-0.18 -0.46,-0.17 -0.63,0.02 -0.37,0.42 -0.56,0.99 -0.52,1.62 0.04,0.74 0.38,1.46 0.9,1.92 0.71,0.63 1.59,0.8 2.31,0.8 z"
                id="path504"
              />
              <path
                class="cls-137"
                d="m 174.53,47.76 c 1.58,0 3.17,-0.88 4,-2.32 l 0.1,-0.17 c 0.1,-0.18 0.19,-0.34 0.3,-0.46 0.37,-0.37 1.03,-0.27 1.73,-0.17 0.15,0.02 0.29,0.05 0.43,0.06 1.11,0.15 2.27,-0.08 3.26,-0.61 0.22,-0.12 0.31,-0.41 0.19,-0.64 -0.12,-0.23 -0.39,-0.32 -0.6,-0.21 -0.83,0.45 -1.82,0.63 -2.75,0.52 l -0.4,-0.06 c -0.81,-0.12 -1.79,-0.27 -2.48,0.42 -0.2,0.21 -0.33,0.44 -0.45,0.66 l -0.09,0.16 c -0.83,1.44 -2.59,2.18 -4.13,1.74 -0.41,-0.12 -0.81,-0.31 -1.22,-0.52 -0.3,-0.15 -0.6,-0.3 -0.92,-0.42 -0.61,-0.24 -1.47,-0.45 -2.26,-0.17 -0.65,-1.31 -0.4,-3.12 0.62,-4.13 0.32,-0.32 0.71,-0.57 1.12,-0.83 0.49,-0.31 0.99,-0.64 1.41,-1.11 0.9,-0.99 1.24,-2.49 0.86,-3.81 -0.07,-0.25 -0.32,-0.4 -0.56,-0.32 -0.24,0.07 -0.37,0.34 -0.3,0.59 0.28,0.98 0.01,2.14 -0.65,2.88 -0.34,0.37 -0.78,0.66 -1.23,0.95 -0.43,0.28 -0.87,0.56 -1.26,0.94 -1.45,1.43 -1.7,3.98 -0.56,5.69 l 0.23,0.35 0.35,-0.2 c 0.63,-0.37 1.47,-0.13 1.91,0.05 0.29,0.11 0.57,0.25 0.85,0.39 0.43,0.21 0.88,0.44 1.37,0.57 0.37,0.11 0.74,0.16 1.12,0.16 z"
                id="path506"
              />
              <path
                class="cls-137"
                d="m 172.56,54.46 c 0.47,0 0.97,-0.11 1.51,-0.31 1.51,-0.57 2.83,-1.67 3.72,-3.08 0.14,-0.22 0.08,-0.51 -0.12,-0.66 -0.21,-0.15 -0.49,-0.09 -0.62,0.13 -0.79,1.25 -1.96,2.21 -3.29,2.72 -0.57,0.22 -1.38,0.41 -2.01,0.07 -0.27,-0.15 -0.51,-0.39 -0.76,-0.64 -0.25,-0.25 -0.51,-0.52 -0.84,-0.72 -0.81,-0.51 -1.75,-0.49 -2.64,-0.42 -0.82,0.06 -1.58,0.11 -2.19,-0.18 -0.33,-0.16 -0.62,-0.48 -0.74,-0.82 -0.06,-0.16 -0.1,-0.4 0,-0.64 0.1,-0.24 0,-0.52 -0.22,-0.63 -0.22,-0.12 -0.49,0 -0.59,0.23 -0.18,0.42 -0.19,0.9 -0.03,1.37 0.21,0.59 0.66,1.09 1.21,1.36 0.82,0.4 1.73,0.33 2.54,0.27 0.83,-0.05 1.62,-0.09 2.21,0.28 0.24,0.15 0.45,0.36 0.68,0.59 0.29,0.29 0.59,0.59 0.98,0.8 0.35,0.19 0.76,0.29 1.21,0.29 z"
                id="path508"
              />
              <path
                class="cls-137"
                d="m 170.05,59.98 c 0.77,0 1.53,-0.18 2.2,-0.36 0.24,-0.06 0.39,-0.32 0.33,-0.57 -0.06,-0.25 -0.31,-0.4 -0.54,-0.35 -0.85,0.23 -1.83,0.45 -2.74,0.25 -0.73,-0.16 -1.58,-0.73 -1.74,-1.61 -0.02,-0.1 -0.03,-0.21 -0.04,-0.32 -0.02,-0.22 -0.04,-0.47 -0.13,-0.72 -0.21,-0.62 -0.76,-1.1 -1.51,-1.3 -0.39,-0.11 -0.77,-0.14 -1.14,-0.16 -0.17,-0.01 -0.34,-0.02 -0.5,-0.05 -2.17,-0.27 -4.14,-2.13 -4.67,-4.38 0.13,-0.17 0.13,-0.52 0,-0.7 -0.14,-0.21 -0.38,-0.29 -0.61,-0.18 -0.22,0.1 -0.42,0.37 -0.33,0.82 0.52,2.79 2.83,5.05 5.49,5.38 0.18,0.02 0.36,0.03 0.54,0.05 0.35,0.02 0.67,0.05 0.98,0.13 0.45,0.13 0.79,0.39 0.89,0.71 0.05,0.14 0.07,0.31 0.08,0.48 0.01,0.14 0.03,0.27 0.05,0.4 0.24,1.32 1.4,2.13 2.44,2.36 0.31,0.07 0.63,0.1 0.94,0.1 z"
                id="path510"
              />
              <path
                class="cls-137"
                d="m 161.59,63.14 c 0.07,0 0.14,0 0.21,-0.02 0.24,-0.03 0.42,-0.27 0.38,-0.53 -0.03,-0.26 -0.27,-0.44 -0.5,-0.4 -0.15,0.01 -0.31,-0.02 -0.44,-0.1 -0.45,-0.3 -0.47,-1.1 -0.44,-1.56 0.06,-1.03 0.31,-2.04 0.73,-2.98 l 0.08,-0.19 c 0.12,-0.26 0.24,-0.53 0.32,-0.84 0.39,-1.52 -0.53,-2.94 -1.49,-4.14 -0.16,-0.2 -0.44,-0.23 -0.63,-0.05 -0.19,0.17 -0.21,0.47 -0.05,0.67 0.8,1 1.58,2.17 1.31,3.27 -0.06,0.23 -0.16,0.45 -0.26,0.67 l -0.09,0.2 c -0.47,1.05 -0.74,2.17 -0.81,3.32 -0.08,1.16 0.22,2 0.85,2.42 0.25,0.17 0.54,0.25 0.83,0.25 z"
                id="path512"
              />
            </g>
          </g>
        </g>
        <g id="g526">
          <path
            class="cls-57"
            d="m 163.8,48.57 h -14.21 c 0,0 2.37,10.63 2.65,20.29 0.28,9.66 0,146.93 0,181.16 0,34.23 1.89,84.59 4.45,84.59 2.56,0 4.45,-50.36 4.45,-84.59 0,-34.23 -0.28,-171.5 0,-181.16 0.28,-9.66 2.65,-20.29 2.65,-20.29 z"
            id="path520"
            style="fill: url(#linear-gradient-137)"
          />
          <path
            class="cls-144"
            d="m 164.62,44.72 c -1.67,-6.05 -7.92,-6.67 -7.92,-6.67 0,0 -6.26,0.63 -7.92,6.67 -1.67,6.05 1.67,10.01 7.92,10.01 6.25,0 9.59,-3.96 7.92,-10.01 z"
            id="path522"
          />
          <path
            class="cls-4"
            d="m 163.79,44.9 c -1.49,-5.41 -7.09,-5.97 -7.09,-5.97 0,0 -5.6,0.56 -7.09,5.97 -1.49,5.41 1.49,8.96 7.09,8.96 5.6,0 8.59,-3.55 7.09,-8.96 z"
            id="path524"
            style="fill: url(#radial-gradient-7)"
          />
        </g>
      </g>
    </svg>
  </div>
</template>

<script setup></script>

<style scoped>
#container {
  width: 600px;
  margin: 0 auto;
  margin-top: 84px;
}
svg {
  width: 600px;
  height: 600px;
  box-shadow: 0 0 10px 5px rgba(0, 0, 0, 0.4);
}
</style>
