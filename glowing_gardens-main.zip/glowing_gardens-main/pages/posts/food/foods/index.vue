<template>
  <div></div>
</template>

<script setup>
//list of foods with some info/notes about each

let foods = ref([
  {
    name: "beef",
    notes: "high in protein, iron, zinc, and B vitamins",
  },
]);
</script>

<style scoped></style>
