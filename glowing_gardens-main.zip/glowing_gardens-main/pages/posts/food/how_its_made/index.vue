<template>
  <div></div>
</template>

<script setup>
let foods = ref([
  {
    name: "Vinegar",
  },
  {
    name: "Mayo",
  },
  {
    name: "Beer",
  },
  {
    name: "Wine",
  },
  {
    name: "Soy Sauce",
  },
  {
    name: "Salad Dressing",
  },
  {
    name: "Ranch",
  },
  {
    name: "Olive Oil",
  },
  {
    name: "Chocolate",
  },
  {
    name: "Butter",
  },
  {
    name: "Flour",
  },
  {
    name: "Rice",
  },
  {
    name: "Sugar",
  },
]);
</script>

<style scoped></style>
