<template>
  <div></div>
</template>

<script setup>
let minerals = ref([
  {
    name: "calcium",
    function: "bone health, muscle function, nerve transmission, and hormone secretion",
    sources: "dairy, leafy greens, nuts, seeds, and fortified foods",
    notes:
      "important for bone health, muscle function, nerve transmission, and hormone secretion",
  },
  {
    name: "iron",
    function: "oxygen transport, DNA synthesis, and energy production",
    sources: "meat, poultry, fish, legumes, and fortified foods",
    notes: "important for oxygen transport, DNA synthesis, and energy production",
  },
  {
    name: "magnesium",
    function:
      "muscle and nerve function, blood glucose control, and blood pressure regulation",
    sources: "nuts, seeds, whole grains, and leafy greens",
    notes:
      "important for muscle and nerve function, blood glucose control, and blood pressure regulation",
  },
  {
    name: "potassium",
    function: "muscle function, nerve transmission, and fluid balance",
    sources: "fruits, vegetables, dairy, and legumes",
    notes: "important for muscle function, nerve transmission, and fluid balance",
  },
  {
    name: "zinc",
    function: "immune function, wound healing, and DNA synthesis",
    sources: "meat, poultry, fish, legumes, and nuts",
    notes: "important for immune function, wound healing, and DNA synthesis",
  },
  {
    name: "phosphorus",
    function: "bone health, energy production, and DNA synthesis",
    sources: "meat, poultry, fish, dairy, and whole grains",
    notes: "important for bone health, energy production, and DNA synthesis",
  },
  {
    name: "sodium",
    function: "fluid balance, nerve function, and muscle function",
    sources: "processed foods, canned foods, and table salt",
    notes: "important for fluid balance, nerve function, and muscle function",
  },
  {
    name: "selenium",
    function: "antioxidant defense, thyroid function, and immune function",
    sources: "seafood, meat, poultry, and nuts",
    notes: "important for antioxidant defense, thyroid function, and immune function",
  },
  {
    name: "copper",
    function: "iron metabolism, energy production, and antioxidant defense",
    sources: "seafood, nuts, seeds, and whole grains",
    notes: "important for iron metabolism, energy production, and antioxidant defense",
  },
  {
    name: "manganese",
    function: "bone health, metabolism, and antioxidant defense",
    sources: "nuts, seeds, whole grains, and leafy greens",
    notes: "important for bone health, metabolism, and antioxidant defense",
  },
  {
    name: "chromium",
    function: "blood sugar control and metabolism",
    sources: "whole grains, nuts, and seeds",
    notes: "important for blood sugar control and metabolism",
  },
  {
    name: "molybdenum",
    function: "enzyme function and metabolism",
    sources: "legumes, nuts, and seeds",
    notes: "important for enzyme function and metabolism",
  },
  {
    name: "iodine",
    function: "thyroid function and metabolism",
    sources: "seafood, dairy, and iodized salt",
    notes: "important for thyroid function and metabolism",
  },
  {
    name: "fluoride",
    function: "dental health and bone health",
    sources: "fluoridated water, tea, and seafood",
    notes: "important for dental health and bone health",
  },
  {
    name: "chloride",
    function: "fluid balance, digestion, and nerve function",
    sources: "table salt, processed foods, and sea vegetables",
    notes: "important for fluid balance, digestion, and nerve function",
  },
]);
</script>

<style scoped></style>
