<template>
  <div></div>
</template>

<script setup>
//and minerals

let vitamins = ref([
  {
    name: "B12",
    notes: "important for nerve function, DNA synthesis, and red blood cell formation",
  },
  {
    name: "B6",
    notes:
      "important for brain development and function, and the formation of red blood cells",
  },
  {
    name: "C",
    notes: "important for the growth and repair of tissues in all parts of your body",
  },
  {
    name: "D",
    notes:
      "important for the absorption of calcium and phosphorus, and for the immune system",
  },
  { name: "E", notes: "important for the immune system, and for the repair of DNA" },
  {
    name: "K",
    notes: "important for blood clotting, and for the health of your bones and heart",
  },
  {
    name: "A",
    notes:
      "important for vision, the immune system, and the health of your skin and mucous membranes",
  },
  {
    name: "Folate (B9)",
    notes: "important for the formation of DNA, and for the growth and repair of tissues",
  },
  {
    name: "Niacin (B3)",
    notes:
      "important for the conversion of food into energy, and for the health of your skin, nerves, and digestive system",
  },
  {
    name: "Riboflavin (B2)",
    notes:
      "important for the conversion of food into energy, and for the health of your skin, nerves, and digestive system",
  },
  {
    name: "Thiamin (B1)",
    notes:
      "important for the conversion of food into energy, and for the health of your skin, nerves, and digestive system",
  },
  {
    name: "Pantothenic Acid (B5)",
    notes:
      "important for the conversion of food into energy, and for the health of your skin, nerves, and digestive system",
  },
  {
    name: "Biotin (B7)",
    notes:
      "important for the conversion of food into energy, and for the health of your skin, nerves, and digestive system",
  },
  {
    name: "Choline",
    notes:
      "important for the conversion of food into energy, and for the health of your skin, nerves, and digestive system",
  },
  {
    name: "Vitamin K",
    notes: "important for blood clotting, and for the health of your bones and heart",
  },
]);
</script>

<style scoped></style>
