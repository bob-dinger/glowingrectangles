<template>
  <div></div>
</template>

<script setup>
//want to show

//teaspoons
//tablespoons
//cups
//fluid ounces

let comps = ref([
  {
    name: "tsp to tbsp",
    description: "",
  },
  {
    name: "tbsp to cups",
    description: "",
  },
  {
    name: "cup",
    description: "",
  },
  {
    name: "fluid ounce",
    description: "",
  },
]);
</script>

<style scoped></style>
