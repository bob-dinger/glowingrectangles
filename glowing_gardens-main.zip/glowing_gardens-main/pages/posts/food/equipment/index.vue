<template>
  <div></div>
</template>

<script setup>
//load in left nav
//click on it?
//to get notes in card container?

let cooking = ref([
  {
    name: "oven",
    image: "",
    description: "",
  },
  {
    name: "microwave",
    image: "",
    description: "",
  },
  {
    name: "air fryer",
    image: "",
    description: "",
  },
  {
    name: "non-stick pan",
    image: "",
    description: "",
  },
  {
    name: "sauce pan",
    image: "",
    description: "",
  },
  {
    name: "cast iron skillet",
    image: "",
    description: "",
  },
  {
    name: "wok",
    image: "",
    description: "carbon steel",
  },
  {
    name: "steamer",
    image: "",
    description: "",
  },
]);
</script>

<style scoped></style>
