<template>
  <div></div>
</template>

<script setup>
let foods = ref([
  {
    name: "Broccoli",
  },
  {
    name: "Eggs",
  },
  {
    name: "Onions",
  },
  {
    name: "Potatoes",
  },
  {
    name: "Carrots",
  },
  {
    name: "Apples",
  },
  {
    name: "Oranges",
  },
  {
    name: "Lettuce",
  },
  {
    name: "Avacados",
  },
  {
    name: "Chicken",
  },
  {
    name: "Beef",
  },
  {
    name: "Pork",
  },
  {
    name: "Salmon",
  },
  {
    name: "Mayo",
  },
  {
    name: "Ketchup",
  },
  {
    name: "Sour Cream",
  },
]);
</script>

<style scoped></style>
