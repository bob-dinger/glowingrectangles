<template>
  <div>
    <img
      src="https://glowinggardensstorage.blob.core.windows.net/images/posts/haidt.png"
    />
  </div>
</template>

<script setup></script>

<style scoped>
img {
  width: 100%;
}
</style>
