<template>
  <div></div>
</template>

<script setup>
let cooking = ref([
  {
    name: "boiling",
    description:
      "boiling is a cooking method that uses hot water or other liquids to cook food. It is a moist-heat cooking technique where the food is cooked in hot water, stock, or other liquids. Boiling is a simple and effective way to cook a variety of foods, including vegetables, pasta, rice, and eggs. It is also used to make soups, stews, and sauces. Boiling is a quick and easy way to cook food, and it is a great way to preserve the natural flavors and nutrients of the food. Boiling is a versatile cooking method that can be used to cook a wide variety of foods. It is a simple and effective way to cook food, and it is a great way to preserve the natural flavors and nutrients of the food. Boiling is a quick and easy way to cook food, and it is a great way to preserve the natural flavors and nutrients of the food.",
  },
  {
    name: "simmering",
    description: "",
  },
  {
    name: "steaming",
    description: "",
  },
  {
    name: "sauteing",
    description: "",
  },
  {
    name: "roasting",
    description: "",
  },
  {
    name: "baking",
    description: "",
  },
  {
    name: "braising",
    description: "",
  },
  {
    name: "stewing",
    description: "",
  },
  {
    name: "poaching",
    description: "",
  },
  {
    name: "blanching",
    description: "",
  },
  {
    name: "sou vide",
    description: "",
  },
  {
    name: "grilling",
    description: "",
  },
  {
    name: "broiling",
    description: "",
  },
  {
    name: "searing",
    description: "",
  },
  {
    name: "frying",
    description: "",
  },
  {
    name: "confit",
    description: "",
  },
]);
</script>

<style scoped></style>
