<template>
  <div>Join the Email List</div>
</template>

<script setup></script>

<style scoped></style>
