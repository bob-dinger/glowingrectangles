

==== title card

====
a computer can only store 1s and 0s. So how the hell do you convert a whole movie to 1s and 0s?




==== number systems
To understand this, first let's use our number system, which is base 10. We use 10 symbols to represent numbers. 
It's very human friendly (probably because we have 10 fingers). 



Our number system uses 10 symbols to encode information. 
But we don't need 10. You can use just 2. 
This is obviously not very human friendly. 
It's much easier to see 171 and know what that means
than 011010 (not right) but they encode the same info

==== images
So to make an image a series of numbers
you divide the image into a grid of pixels
each pixel has a color value
that value can be encoded as a number
It is 3 numbers (RGB) that combine to create a unique color
255 x 255 x 255



==== audio





==== video

==== text



