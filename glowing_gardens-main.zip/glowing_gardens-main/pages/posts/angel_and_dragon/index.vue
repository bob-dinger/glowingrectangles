<template>
    <div style="width:610px;margin:0 auto;">
    <MyComponent />
    </div>
</template>

<script setup>
import MyComponent from './my_component.vue'

onMounted(() => {
    // let circler = document.querySelector('#circler');
    // circler.setAttribute("fill", "blue");

})

</script>

<style scoped>

</style>