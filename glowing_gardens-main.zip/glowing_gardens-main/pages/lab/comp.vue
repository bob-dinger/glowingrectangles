<template>
  <div style="width: 600px; margin: 0 auto; margin-top: 24px; position: relative">
    <SvgBoxGrid />
  </div>
</template>

<script setup></script>

<style scoped></style>
